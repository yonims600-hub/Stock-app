"""
pivot_view.py · עמוד 2: מתחת לרדאר — פיבוט עסקי, שלושה שלבים וציונים חיים.
שלב 1 סריקה → שלב 2 צ'ק-ליסט (4 תנאים) → שלב 3 שאלון (7 חלקים) → פסק דין.
"""
from __future__ import annotations

import copy
import math

import pandas as pd
import streamlit as st

import assistant
import core
import datahub
import ui

YES_NO = {True: "כן", False: "לא"}
ANSWER = {0: "✕ לא", 1: "~ חלקי", 2: "✓ כן"}
TONE_ICON = {"good": "🟢", "warn": "🟡", "bad": "🔴", "neutral": "⚪"}


def render() -> None:
    store = core.load_store()
    ui.init_params(store)
    pp = ui.current_pivot_params()
    dev = ui.detect_device()
    st.title("מתחת לרדאר")
    st.caption("חברות שדשדשו שנה ומעלה, עושות פיבוט עסקי ועוד לא עלו — מסנן, צ׳ק-ליסט, שאלון וציון חי")
    t_an, t_scan, t_rank = st.tabs([":material/analytics: ניתוח מניה", ":material/radar: סורק שלב 1", ":material/leaderboard: דירוג"])
    with t_an:
        _tab_analysis(store, pp, dev)
    with t_scan:
        _tab_scan(store, pp)
    with t_rank:
        _tab_rank(store, pp)


# ════════════════════════════ מצב וחישוב ════════════════════════════
def _rec_from_state(sym: str, saved: dict | None) -> dict:
    """בונה את רשומת המחקר ממצב הווידג'טים (כך שהציון בראש העמוד תמיד מעודכן באותה ריצה)."""
    ss, base = st.session_state, core.new_pivot_record()
    rec = copy.deepcopy(saved) if saved else base
    for k, v in base["s2"].items():
        rec["s2"].setdefault(k, v)
    for q in core.QUESTIONS:
        ss.setdefault(f"qa|{sym}|{q[0]}", rec["answers"].get(q[0]))
    for k in base["s2"]:
        ss.setdefault(f"s2|{sym}|{k}", rec["s2"].get(k))
    ss.setdefault(f"mat|{sym}", rec.get("maturity"))
    ss.setdefault(f"tps|{sym}", rec.get("target_ps"))
    ss.setdefault(f"note|{sym}", rec.get("note", ""))
    out = core.new_pivot_record()
    out["answers"] = {q[0]: ss[f"qa|{sym}|{q[0]}"] for q in core.QUESTIONS if ss[f"qa|{sym}|{q[0]}"] is not None}
    out["s2"] = {k: ss[f"s2|{sym}|{k}"] for k in base["s2"]}
    out["maturity"], out["target_ps"], out["note"] = ss[f"mat|{sym}"], ss[f"tps|{sym}"], ss[f"note|{sym}"]
    return out


def _compute(df, info, ins, events, deep, rec: dict, pp: core.PivotParams) -> dict:
    m = core.pivot_metrics(df, info, ins, pp, events, deep)
    auto = core.auto_answers(m, rec, pp)
    s2 = core.stage2_eval(m, rec, pp)
    sc = core.score_pivot(rec["answers"], auto)
    mat = rec["maturity"] or m["maturity_suggested"]
    vd = core.verdict(s2["passed"], sc["total"], sc["completeness"], m.get("runway"), mat, m["ev"]["red_flags"])
    return {"m": m, "auto": auto, "s2": s2, "sc": sc, "mat": mat, "vd": vd}


def _pick() -> None:
    if st.session_state.get("pv_pick"):
        st.session_state["pv_sym"] = st.session_state["pv_pick"]


def _fmt(v, fmt_: str = "{:,.1f}", suffix: str = "") -> str:
    return "—" if v is None or (isinstance(v, float) and math.isnan(v)) else fmt_.format(v) + suffix


def _s2_rows(items: list) -> None:
    import html
    rows = "".join(
        f'<div class="cond"><span class="ci {"na" if i["value"] is None else "ok" if i["value"] else "no"}">'
        f'{"?" if i["value"] is None else "✓" if i["value"] else "✕"}</span>'
        f'<div><b>{html.escape(i["label"])}</b><small>{html.escape(i["detail"])}</small></div></div>' for i in items)
    st.markdown(rows, unsafe_allow_html=True)


# ════════════════════════════ ניתוח מניה ════════════════════════════
def _tab_analysis(store: dict, pp: core.PivotParams, dev: dict) -> None:
    saved_syms = sorted(store["pivot"])
    if saved_syms:
        st.pills("שמורות במחקר", saved_syms, key="pv_pick", on_change=_pick)
    sym = ui.symbol_input("סימול לניתוח", "pv_sym", saved_syms[0] if saved_syms else "AAPL")
    if not sym:
        return
    with st.spinner("אוסף נתונים: מחירים, דוחות, Form 4 ו-8-K…"):
        df = core.download_ohlc((sym,), "5y").get(sym)
        if df is None or len(df) < 60:
            st.error("לא נמצאו מספיק נתונים לסימול. בדוק את האיות או את מצב המקורות.")
            ui.health_panel()
            return
        info, ins = core.get_info(sym), core.get_insiders(sym)
        events, deep = core.sec_events(sym), core.fundamentals_deep(sym)

    rec = _rec_from_state(sym, store["pivot"].get(sym))
    if rec != (store["pivot"].get(sym) or core.new_pivot_record()):
        store["pivot"][sym] = rec
        core.save_store(store)
    r = _compute(df, info, ins, events, deep, rec, pp)
    m, auto, s2, sc, mat, vd = r["m"], r["auto"], r["s2"], r["sc"], r["mat"], r["vd"]
    ui.set_ctx("pivot", assistant.ctx_from_pivot(sym, m, sc, s2, vd, pp, mat))

    st.markdown(f"### {m['name'] or sym}")
    st.caption(f"{m['sector'] or '—'} · {m['industry'] or '—'}")
    ui.src_caption(sym)
    g, v = st.columns([2, 3], vertical_alignment="center")
    g.plotly_chart(ui.gauge_chart(sc["total"]), width="stretch", config=ui.PLOT_CFG)
    with v:
        ui.status_card(vd[2], vd[1], f"השלמת מחקר {sc['completeness'] * 100:.0f}% · שלב בשלות {mat} · שלב 1: {m['s1_met']}/4")
        ui.chips([(f"דשדוש {m['flat_days'] / 252:.1f} שנים", "good" if m["dormant"] else "warn"),
                  (f"{m['dd']:.0f}% משיא 3 שנים", "good" if m["battered"] else "warn"),
                  (f"אינסיידרים: {m['ins']['buys']} קניות", "good" if m["insider_buy"] else "warn"),
                  (f"8-K: {m['ev']['mgmt']} שינויי הנהלה", "good" if m["ev"]["mgmt"] else "warn")])

    names = ["שלב 1", "שלב 2", "שלב 3", "פיננסי", "הנהלה ואינסיידרים", "שווי", "שור/דוב", "פסק דין"]
    s1, s2t, s3, fin, hum, val, bb, fin_v = st.tabs(names)
    with s1:
        _stage1(df, m, pp, dev)
    with s2t:
        _stage2(sym, s2, pp)
    with s3:
        _stage3(sym, sc, auto)
    with fin:
        _financials(m, dev)
    with hum:
        _human(sym, m, ins)
    with val:
        _valuation(sym, m)
    with bb:
        _bull_bear(m, sc, s2, pp)
    with fin_v:
        _verdict(sym, m, sc, s2, mat, vd)


def _stage1(df: pd.DataFrame, m: dict, pp: core.PivotParams, dev: dict) -> None:
    st.plotly_chart(ui.pivot_chart(df, m, ui.chart_height(dev, 420)), width="stretch", config=ui.PLOT_CFG)
    a = st.columns(4)
    a[0].metric("ימי דשדוש", f"{m['flat_days']}", f"{m['flat_days'] / 252:.1f} שנים")
    a[1].metric("משיא 3 שנים", f"{m['dd']:.0f}%")
    a[2].metric("משפל 52 שבועות", f"{m['rise52']:+.0f}%")
    a[3].metric("שינוי 3 חודשים", _fmt(m["ret3m"], "{:+.0f}", "%"))
    ui.cond_rows([
        (f"דשדוש ממושך (≥{pp.min_flat_days} ימי מסחר)", m["dormant"], f"{m['flat_days']} ימים בטווח {m['flat_lo']:.2f}–{m['flat_hi']:.2f}"),
        (f"מניה חבוטה (ירידה ≥{pp.min_dd:g}% משיא 3 שנים)", m["battered"], f"{m['dd']:.0f}%"),
        (f"עוד לא עלתה (≤{pp.max_rise:g}% משפל שנה)", m["quiet"], f"{m['rise52']:+.0f}% משפל · {_fmt(m['ret3m'], '{:+.0f}', '%')} ב-3 חודשים"),
        (f"אינסיידרים קונים ({pp.insider_days} ימים)", m["insider_buy"], f"{m['ins']['buys']} רכישות, {m['ins']['buyers']} קונים, ≈${m['ins']['value']:,.0f}"),
    ])
    st.caption("הטווח הכתום בגרף הוא תקופת הדשדוש הנוכחית; ▲ ירוק הוא קניית אינסיידר.")


def _stage2(sym: str, s2: dict, pp: core.PivotParams) -> None:
    _s2_rows(s2["items"])
    if s2["passed"] is True:
        ui.status_card("good", "כל ארבעת התנאים התקיימו", "ממשיכים לשלב 3 — שאלון המחקר")
    elif s2["passed"] is False:
        ui.status_card("bad", "לפחות תנאי אחד לא התקיים", "לפי השיטה: לא ממשיכים עם החברה הזו")
    else:
        ui.status_card("warn", "חסר מידע", "השלם את התנאים שמסומנים ב-?")
    st.markdown("##### עדכון ידני")
    st.caption("ערך ידני גובר על האוטומטי. ריק = לפי הנתונים.")
    a, b = st.columns(2)
    a.segmented_control(f"מזומנים ל-{pp.runway_min}+ חודשים", [True, False], format_func=YES_NO.get, key=f"s2|{sym}|cash")
    b.segmented_control("הוחלפה הנהלה", [True, False], format_func=YES_NO.get, key=f"s2|{sym}|mgmt")
    c, d = st.columns(2)
    c.number_input("צמיחת המגזר החדש (%)", value=None, placeholder="ריק = מקורב מההכנסות", key=f"s2|{sym}|seg", step=1.0)
    d.segmented_control("לקוח עוגן / שותף אסטרטגי", [True, False], format_func=YES_NO.get, key=f"s2|{sym}|anchor")


def _stage3(sym: str, sc: dict, auto: dict) -> None:
    st.caption("ענה לכל שאלה: ✓ כן · ~ חלקי · ✕ לא. 🤖 = הערכה אוטומטית מהנתונים (התשובה שלך גוברת עליה). הציון מתעדכן מיד.")
    for pid, (title, w, icon) in core.PARTS.items():
        part = sc["parts"][pid]
        score = "—" if part["score"] is None else f"{part['score']:.0f}"
        with st.expander(f"חלק {pid} · {title} · {score}", expanded=(pid == 1), icon=icon):
            st.caption(f"משקל {w}% · נענו {part['answered']}/{part['total']}")
            for q in (x for x in core.QUESTIONS if x[1] == pid):
                qid = q[0]
                st.markdown(f"**{qid}** {q[2]}")
                hint = f"🤖 הערכה אוטומטית: {ANSWER[auto[qid]]}" if qid in auto else ""
                st.caption((q[3] + (" · " if hint else "") + hint))
                st.segmented_control(q[2], [0, 1, 2], format_func=ANSWER.get, key=f"qa|{sym}|{qid}", label_visibility="collapsed")
    st.text_area("הערות מחקר", key=f"note|{sym}", placeholder="תובנות, קישורים, מה לבדוק בדוח הבא…")


def _financials(m: dict, dev: dict) -> None:
    rw = m.get("runway")
    a = st.columns(3)
    a[0].metric("מסלול מזומנים", "∞ (תזרים חיובי)" if rw == 999 else _fmt(rw, "{:.0f}", " חודשים"))
    a[1].metric("צמיחת הכנסות", _fmt(m.get("rev_growth"), "{:+.1f}", "%"))
    a[2].metric("שולי רווח גולמי", _fmt(m.get("gross_margin"), "{:.1f}", "%"))
    b = st.columns(3)
    b[0].metric("P/S", _fmt(m.get("ps"), "{:.2f}"))
    b[1].metric("תזרים חופשי", _fmt(m.get("fcf"), "${:,.0f}"))
    b[2].metric("דילול מניות", _fmt(m.get("dilution"), "{:+.1f}", "%"))
    st.caption(f"מקור מסלול המזומנים: {m.get('runway_src')}. מבוסס על ממוצע תזרים של שני הרבעונים האחרונים.")
    fig = ui.fundamentals_chart(m.get("deep") or {}, ui.chart_height(dev, 560))
    if fig:
        st.plotly_chart(fig, width="stretch", config=ui.PLOT_CFG)
    else:
        st.info("אין דוחות רבעוניים זמינים לסימול (ייתכן שמקור הנתונים מושהה). מוצגים נתוני הסיכום בלבד.")
    if m.get("target"):
        st.caption(f"יעד אנליסטים ממוצע: ${m['target']:,.2f}")


def _human(sym: str, m: dict, ins) -> None:
    s = m["ins"]
    a = st.columns(4)
    a[0].metric("קניות (180 יום)", s["buys"])
    a[1].metric("מכירות", s["sells"])
    a[2].metric("קונים שונים", s["buyers"])
    a[3].metric("שווי קניות", f"${s['value']:,.0f}")
    if s["rows"] is not None:
        st.dataframe(s["rows"], hide_index=True, width="stretch")
        src = ins["Source"].iloc[0] if ins is not None and "Source" in ins else "—"
        st.caption(f"מקור: {src}. קנייה בשוק הפתוח (Form 4, קוד P) של מנכ״ל/דירקטור היא האות החזק ביותר.")
    else:
        st.info("לא נמצאו רכישות אינסיידרים בתקופה (או שהמקורות לא החזירו נתונים).")
    ev = m["ev"]
    st.markdown("##### דיווחי 8-K רשמיים (12 חודשים)")
    if not ev["available"]:
        st.caption("אין נתוני SEC לסימול (חברה לא אמריקאית, או שהמקור מושהה — ראה מצב מקורות).")
    else:
        chips = [(f"{datahub.EVENT_LABELS[t]}: {ev[t]}", "bad" if t in datahub.RED_FLAG_TAGS or t in ("dilution", "termination") else "good")
                 for t in datahub.EVENT_TAGS if ev[t]]
        ui.chips(chips or [("אין אירועים מסווגים", "warn")])
        if ev["all"]:
            rows = [{"תאריך": e["date"], "סוג": ", ".join(datahub.EVENT_LABELS[t] for t in e["tags"]) or "—",
                     "סעיפים": ", ".join(e["items"]), "מסמך": e["url"]} for e in ev["all"] if e["tags"]]
            if rows:
                st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch",
                             column_config={"מסמך": st.column_config.LinkColumn(display_text="פתח")})
    news = core.get_news(sym)
    with st.expander(f"כותרות אחרונות ({len(news)})", icon=":material/newspaper:"):
        for n in news[:12]:
            when = n["time"].strftime("%d/%m") if n.get("time") else ""
            st.markdown(f"[{n['title']}]({n['url']}) · {n['publisher']} {when}" if n.get("url") else n["title"])
        if not news:
            st.caption("לא התקבלו כותרות.")
        st.caption("כותרות הן מידע חיצוני לא מאומת.")


def _valuation(sym: str, m: dict) -> None:
    a = st.columns(3)
    a[0].metric("P/S נוכחי", _fmt(m.get("ps"), "{:.2f}"))
    a[1].metric("מכירות למניה", _fmt(m.get("rps"), "${:.2f}"))
    a[2].metric("מחיר", f"${m['price']:,.2f}")
    st.number_input("מכפיל מכירות יעד (P/S) אם הפיבוט יצליח", value=None, min_value=0.1, max_value=50.0, step=0.5,
                    placeholder="לדוגמה 3.0", key=f"tps|{sym}")
    tps = st.session_state.get(f"tps|{sym}")
    up = core.rerate_upside(m, tps)
    if up is not None:
        st.metric("פוטנציאל Re-Rating", f"{up:+.0f}%", f"מחיר מרומז ${tps * m['rps']:,.2f}")
    if m.get("rps"):
        rows = [{"P/S": x, "מחיר מרומז": x * m["rps"], "פוטנציאל %": (x * m["rps"] / m["price"] - 1) * 100} for x in (1, 2, 3, 5, 8)]
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch",
                     column_config={"מחיר מרומז": st.column_config.NumberColumn(format="$%.2f"),
                                    "פוטנציאל %": st.column_config.NumberColumn(format="%+.0f%%")})
        st.caption("טבלת רגישות על בסיס מכירות נוכחיות בלבד. מכפיל גבוה מצדיק עצמו רק אם המכירות באמת צומחות.")
    else:
        st.info("אין נתון מכירות למניה לחישוב מחיר מרומז.")


def _bull_bear(m: dict, sc: dict, s2: dict, pp: core.PivotParams) -> None:
    bull, bear = core.bull_bear(m, sc, s2, pp)
    c1, c2 = st.columns(2)
    c1.success("🐂 **הטיעון השורי**\n\n" + ("\n".join(f"- {x}" for x in bull) or "- אין עדיין נקודות בולטות"))
    c2.error("🐻 **הטיעון הדובי**\n\n" + ("\n".join(f"- {x}" for x in bear) or "- אין עדיין נקודות בולטות"))
    st.caption("הרשימות נבנות אוטומטית מהנתונים ומתשובות השאלון, ומתעדכנות ככל שתענה.")


def _verdict(sym: str, m: dict, sc: dict, s2: dict, mat: int, vd: tuple) -> None:
    st.markdown("##### היכן החברה על ציר הזמן של המהפך?")
    st.segmented_control("שלב בשלות", [1, 2, 3, 4], format_func=lambda i: f"{i} · {core.MATURITY[i]}", key=f"mat|{sym}")
    st.caption(f"הצעה אוטומטית: שלב {m['maturity_suggested']} (לפי צמיחה ורווחיות). ריק = ההצעה.")
    ui.maturity_steps(mat)
    ui.status_card(vd[2], vd[1], f"ציון איכות {_fmt(sc['total'], '{:.0f}')}/100 · השלמה {sc['completeness'] * 100:.0f}%")
    st.plotly_chart(ui.radar_chart(sc["parts"]), width="stretch", config=ui.PLOT_CFG)
    st.caption("זהו מודל דירוג עזר שמסכם את תשובותיך ואת הנתונים. הוא לא ייעוץ השקעות ולא תחליף לקריאת הדוחות.")


# ════════════════════════════ סורק שלב 1 ════════════════════════════
def _tab_scan(store: dict, pp: core.PivotParams) -> None:
    st.caption("הדבק סימולים (למשל מרשימת קניות אינסיידרים או מסנן) והסורק יבדוק: דשדוש, חבטה, ״עוד לא עלתה״ ורכישות אינסיידרים.")
    st.link_button("OpenInsider · קניות אינסיידרים מקובצות", "https://www.openinsider.com/latest-cluster-buys",
                   icon=":material/open_in_new:")
    txt = st.text_area("סימולים", key="pv_scan_txt", placeholder="ABCD EFGH IJKL")
    with st.expander("קריטריונים", icon=":material/tune:"):
        a, b = st.columns(2)
        a.number_input("אורך דשדוש מינימלי (ימי מסחר)", min_value=60, max_value=1000, step=10, key="pv_min_flat_days")
        b.number_input("טווח דשדוש (יחס מקס׳/מין׳)", min_value=1.2, max_value=4.0, step=0.1, key="pv_band")
        c, d = st.columns(2)
        c.number_input("ירידה מינימלית משיא 3 שנים (%)", min_value=10.0, max_value=95.0, step=5.0, key="pv_min_dd")
        d.number_input("עלייה מקסימלית משפל שנה (%)", min_value=5.0, max_value=200.0, step=5.0, key="pv_max_rise")
        e, f = st.columns(2)
        e.number_input("מסלול מזומנים מינימלי (חודשים)", min_value=6, max_value=48, step=1, key="pv_runway_min")
        f.number_input("צמיחת מגזר מינימלית (%)", min_value=5.0, max_value=100.0, step=5.0, key="pv_seg_min")
    if st.button("סרוק שלב 1", type="primary", icon=":material/radar:", width="stretch", key="pv_scan_btn"):
        syms = txt.replace(",", " ").split()
        if not syms:
            st.warning("הדבק לפחות סימול אחד.")
        else:
            bar = st.progress(0.0, text="מתחיל…")
            rows = core.stage1_scan(syms, pp, progress=lambda f, s: bar.progress(min(f, 1.0), text=f"בודק {s}"))
            bar.empty()
            st.session_state["pv_scan"] = rows
    rows = st.session_state.get("pv_scan")
    if rows is None:
        return
    if not rows:
        st.error("לא התקבלו נתונים. בדוק את הסימולים או את מצב המקורות.")
        return
    yn = lambda b: "✅" if b else "❌"  # noqa: E731
    df = pd.DataFrame([{"סימול": r["symbol"], "עברו": f"{r['s1_met']}/4", "דשדוש": yn(r["dormant"]),
                        "שנים": r["flat_days"] / 252, "חבוטה": yn(r["battered"]), "מהשיא %": r["dd"], "עוד לא עלתה": yn(r["quiet"]),
                        "משפל %": r["rise52"], "אינסיידרים": yn(r["insider_buy"]), "קניות": r["buys"]} for r in rows])
    event = st.dataframe(df, hide_index=True, width="stretch", on_select="rerun", selection_mode="multi-row", key="pv_scan_tbl",
                         column_config={"שנים": st.column_config.NumberColumn(format="%.1f"),
                                        "מהשיא %": st.column_config.NumberColumn(format="%.0f%%"),
                                        "משפל %": st.column_config.NumberColumn(format="%+.0f%%")})
    sel = getattr(getattr(event, "selection", None), "rows", None) or []
    if sel and st.button(f"שמור {len(sel)} לרשימת המחקר", icon=":material/bookmark_add:", key="pv_scan_save"):
        for i in sel:
            store["pivot"].setdefault(rows[i]["symbol"], core.new_pivot_record())
        core.save_store(store)
        st.toast("נשמר. אפשר לפתוח אותן בלשונית ״ניתוח מניה״", icon=":material/check_circle:")


# ════════════════════════════ דירוג ════════════════════════════
def _tab_rank(store: dict, pp: core.PivotParams) -> None:
    syms = sorted(store["pivot"])
    if not syms:
        st.info("עדיין אין מניות במחקר. נתח מניה או שמור תוצאות מהסורק.")
        return
    st.caption("הציונים מחושבים מחדש מנתונים עדכניים ומתשובותיך השמורות.")
    data = core.download_ohlc(tuple(syms), "5y")
    rows = []
    with st.spinner("מחשב ציונים…"):
        for s in syms:
            df = data.get(s)
            if df is None or len(df) < 60:
                rows.append({"סימול": s, "פסק דין": "אין נתונים"})
                continue
            rec = store["pivot"][s]
            for k, v in core.new_pivot_record()["s2"].items():
                rec["s2"].setdefault(k, v)
            r = _compute(df, core.get_info(s), core.get_insiders(s), core.sec_events(s), core.fundamentals_deep(s), rec, pp)
            rows.append({"סימול": s, "ציון": r["sc"]["total"], "השלמה %": r["sc"]["completeness"] * 100,
                         "שלב 2": {True: "✅", False: "❌", None: "?"}[r["s2"]["passed"]], "בשלות": r["mat"],
                         "פסק דין": f"{TONE_ICON[r['vd'][2]]} {r['vd'][1]}", "מחיר": r["m"]["price"],
                         "דשדוש (שנים)": r["m"]["flat_days"] / 252, "מהשיא %": r["m"]["dd"]})
    df_out = pd.DataFrame(rows)
    if "ציון" in df_out:
        df_out = df_out.sort_values("ציון", ascending=False, na_position="last")
    st.dataframe(df_out, hide_index=True, width="stretch",
                 column_config={"ציון": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%d"),
                                "השלמה %": st.column_config.NumberColumn(format="%.0f%%"),
                                "מחיר": st.column_config.NumberColumn(format="$%.2f"),
                                "דשדוש (שנים)": st.column_config.NumberColumn(format="%.1f"),
                                "מהשיא %": st.column_config.NumberColumn(format="%.0f%%")})
    rm = st.selectbox("הסר מהמחקר", [""] + syms, key="pv_rm")
    if rm and st.button("הסר", icon=":material/delete:", key="pv_rm_btn"):
        store["pivot"].pop(rm, None)
        core.save_store(store)
        st.rerun()
