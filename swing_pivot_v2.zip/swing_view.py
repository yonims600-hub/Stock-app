"""
swing_view.py · עמוד 1: סווינג — בדיקת מניה לפי הכללים שלך, סורק הזדמנויות, התראות, בקטסט וכללים.
"""
from __future__ import annotations

import math
import secrets
from dataclasses import asdict
from datetime import date, datetime

import pandas as pd
import streamlit as st

import assistant
import core
import datahub
import ui

RANGES = {"3 חודשים": 63, "6 חודשים": 126, "שנה": 252, "שנתיים": 504}


def render() -> None:
    store = core.load_store()
    ui.init_params(store)
    p = ui.current_params()
    dev = ui.detect_device()
    st.title("סווינג")
    st.caption("נר ירוק נקי מעל הממוצע · עד 4% מהקו · יציאה בנר אדום מתחתיו")
    t_check, t_scan, t_alert, t_bt, t_rules = st.tabs([
        ":material/search: בדיקה", ":material/radar: סורק", ":material/notifications_active: התראות",
        ":material/science: בקטסט", ":material/tune: כללים"])
    with t_check:
        _tab_check(store, p, dev)
    with t_scan:
        _tab_scan(store, p)
    with t_alert:
        _tab_alerts(store, p)
    with t_bt:
        _tab_backtest(p, dev)
    with t_rules:
        _tab_rules(store, dev)


# ════════════════════════════ בדיקת מניה ════════════════════════════
def _market_chip(p: core.Params) -> tuple[str, str] | None:
    spy = core.download_ohlc(("SPY",), "1y").get("SPY")
    if spy is None or len(spy) < p.ma_len + 1:
        return None
    ma = spy["Close"].rolling(p.ma_len).mean().iloc[-1]
    up = spy["Close"].iloc[-1] > ma
    return (f"השוק הרחב (SPY) {'מעל' if up else 'מתחת ל'}-MA{p.ma_len}", "good" if up else "warn")


def _tab_check(store: dict, p: core.Params, dev: dict) -> None:
    sym = ui.symbol_input("סימול מניה", "sw_sym", "AAPL")
    if not sym:
        st.info("הזן סימול כדי לבדוק אם המניה בנקודת כניסה.")
        return
    with st.spinner("טוען נתונים…"):
        df = core.download_ohlc((sym,), "2y").get(sym)
    if df is None:
        st.error("לא נמצאו נתונים לסימול. בדוק את האיות (למניה בת״א הוסף .TA, למשל NICE.TA).")
        ui.health_panel()
        return
    ev = core.evaluate(df, p, sym, core.tz_for(sym))
    if ev is None:
        st.warning("אין מספיק היסטוריה לחישוב הממוצע.")
        return
    ui.set_ctx("swing", assistant.ctx_from_eval(ev, p))
    sub = f"{sym} · נר {ev.asof}" + (" · נר היום עדיין פתוח ולא נספר" if ev.live_dropped else "")
    ui.status_card(ev.tone, ev.label, sub)
    ui.src_caption(sym)

    q = core.get_quote(sym)
    k = st.columns(4)
    k[0].metric("מחיר חי" if q else "סגירה", f"{(q or {}).get('last', ev.price):,.2f}", f"{q['pct']:+.2f}%" if q else None)
    k[1].metric(f"מרחק מ-MA{p.ma_len}", f"{ev.dist:+.1f}%")
    k[2].metric("RSI", f"{ev.rsi:.0f}" if not math.isnan(ev.rsi) else "—")
    k[3].metric("נפח מול ממוצע", f"{ev.volx:.1f}×" if not math.isnan(ev.volx) else "—")

    chips = [(f"{ev.met}/4 תנאי כניסה", "good" if ev.met == 4 else "warn" if ev.met == 3 else "bad")]
    mk = _market_chip(p)
    if mk:
        chips.append(mk)
    if ev.surge_recent:
        chips.append((f"קפיצה {ev.surge_gain:+.0f}% · יציאה לפי MA{p.fast_len}", "warn"))
    ui.chips(chips)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### תנאי כניסה")
        ui.cond_rows(ev.conds)
    with c2:
        st.markdown("##### אם אתה כבר בפנים")
        ui.cond_rows(ev.sell_conds)
        if ev.surge_recent:
            st.caption(f"במצב קפיצה היציאה היא נר אדום שנסגר מתחת ל-MA{p.fast_len} ({ev.maf:,.2f}).")

    r1, r2 = st.columns([3, 2], vertical_alignment="bottom")
    rng = r1.segmented_control("טווח גרף", list(RANGES), default="6 חודשים", key="sw_range") or "6 חודשים"
    show_fast = r2.toggle(f"הצג MA{p.fast_len}", value=ev.surge_recent, key=f"sw_fast_{sym}")
    st.plotly_chart(ui.swing_chart(ev.d, p, RANGES[rng], ui.chart_height(dev), show_fast), width="stretch", config=ui.PLOT_CFG)
    st.caption("▲ כניסה · ▼ יציאה · ★ קפיצה לפי הכללים. האזור הירוק: טווח הכניסה (עד "
               f"{p.max_dist:g}% מעל MA{p.ma_len}).")

    with st.expander("מחשבון גודל פוזיציה (הסטופ הוא הממוצע)", icon=":material/calculate:"):
        a, b, c = st.columns(3)
        account = a.number_input("גודל תיק ($)", 1000.0, value=50000.0, step=1000.0, key="sz_acc")
        risk = b.number_input("סיכון לעסקה (%)", 0.1, 5.0, 1.0, 0.1, key="sz_risk")
        cap = c.number_input("מקס׳ פוזיציה (% מהתיק)", 5.0, 100.0, 25.0, 5.0, key="sz_cap")
        risk_ps = max(ev.price - ev.ma, 0.005 * ev.price)
        shares = math.floor(min(account * risk / 100 / risk_ps, account * cap / 100 / ev.price))
        m = st.columns(4)
        m[0].metric("סטופ (MA)", f"{ev.ma:,.2f}")
        m[1].metric("סיכון למניה", f"{risk_ps / ev.price * 100:.1f}%")
        m[2].metric("כמות מניות", f"{shares:,}")
        m[3].metric("שווי פוזיציה", f"${shares * ev.price:,.0f}")
        st.caption("הכניסה עד 4% מהקו נועדה לשמור על סיכון קטן: המרחק לסטופ קטן, ולכן אפשר לקנות כמות גדולה יחסית בסיכון קבוע.")

    b1, b2 = st.columns(2)
    if b1.button("עקוב אחרי המניה", icon=":material/visibility:", width="stretch", key="sw_add_watch"):
        core.upsert_position(store, sym, "watch")
        core.save_store(store)
        st.toast(f"{sym} נוספה לרשימת ההתראות (מעקב)", icon=":material/check_circle:")
    if b2.button("אני בפנים", icon=":material/work:", width="stretch", key="sw_add_held"):
        core.upsert_position(store, sym, "held", entry_price=round(ev.price, 2))
        core.save_store(store)
        st.toast(f"{sym} נוספה כפוזיציה פתוחה", icon=":material/check_circle:")


# ════════════════════════════ סורק ════════════════════════════
def _scan_table(title: str, evs: list[core.Eval], store: dict, key: str, note: bool = False) -> None:
    st.markdown(f"##### {title} · {len(evs)}")
    if not evs:
        st.caption("אין תוצאות.")
        return
    rows = [{"סימול": e.symbol, "מחיר": e.price, "מרחק %": e.dist, "ציון": e.score if e.code == "ENTRY" else None,
             "RSI": e.rsi, "נפח ×": e.volx, "הערה": e.missing if note else e.label} for e in evs]
    event = st.dataframe(
        pd.DataFrame(rows), hide_index=True, width="stretch", on_select="rerun", selection_mode="multi-row", key=key,
        column_config={"מחיר": st.column_config.NumberColumn(format="%.2f"), "מרחק %": st.column_config.NumberColumn(format="%+.1f%%"),
                       "ציון": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%d"),
                       "RSI": st.column_config.NumberColumn(format="%.0f"), "נפח ×": st.column_config.NumberColumn(format="%.1f")})
    sel = getattr(getattr(event, "selection", None), "rows", None) or []
    if sel and st.button(f"הוסף {len(sel)} נבחרות למעקב", icon=":material/add_alert:", key=f"{key}_add"):
        for i in sel:
            core.upsert_position(store, evs[i].symbol, "watch")
        core.save_store(store)
        st.toast("נוספו לרשימת ההתראות", icon=":material/check_circle:")


def _tab_scan(store: dict, p: core.Params) -> None:
    st.caption("סורק מניות שעומדות עכשיו בכללי הכניסה שלך. הציון הוא דירוג עזר (קרבה לקו, מגמה, נפח ו-RSI) ולא חלק מהכללים.")
    names = list(core.UNIVERSES) + ["הרשימה שלי", "מותאם אישית"]
    choice = st.selectbox("אוניברסום", names, key="sw_uni")
    custom = ""
    if choice == "מותאם אישית":
        custom = st.text_area("סימולים (מופרדים ברווח או פסיק)", key="sw_uni_custom", placeholder="NVDA MSFT NICE.TA")
    if st.button("סרוק עכשיו", type="primary", icon=":material/radar:", width="stretch", key="sw_scan_btn"):
        if choice == "הרשימה שלי":
            syms = [x["symbol"] for x in store["positions"]]
        elif choice == "מותאם אישית":
            syms = custom.replace(",", " ").split()
        else:
            syms = core.UNIVERSES[choice]
        if not syms:
            st.warning("אין סימולים לסריקה.")
        else:
            with st.spinner(f"סורק {len(syms)} מניות…"):
                res = core.scan_universe(syms, p)
            st.session_state["sw_scan"] = {"t": datetime.now().strftime("%H:%M"), "uni": choice, "res": res, "asked": len(syms)}
    data = st.session_state.get("sw_scan")
    if not data:
        st.info("לחץ ״סרוק עכשיו״ כדי לקבל רשימת מניות בנקודת כניסה.")
        return
    res = data["res"]
    if not res:
        st.error("לא התקבלו נתונים מהמקורות. ראה מצב מקורות בלשונית ״כללים״.")
        return
    st.caption(f"{data['uni']} · נסרקו {len(res)} מתוך {data['asked']} · {data['t']} · נרות סגורים בלבד")
    entries = sorted([e for e in res if e.code == "ENTRY"], key=lambda e: -e.score)
    near = sorted([e for e in res if e.code == "NEAR"], key=lambda e: -e.score)
    surges = [e for e in res if e.code == "SURGE"]
    _scan_table("בנקודת כניסה", entries, store, "scan_entry")
    _scan_table("קרובות לכניסה (חסר תנאי אחד)", near, store, "scan_near", note=True)
    with st.expander(f"קפיצות חדות ({len(surges)}) — לא רודפים"):
        _scan_table("קפיצות", surges, store, "scan_surge")
    st.caption("זה כלי סינון לפי הכללים שלך, לא המלצת השקעה. לפני כל עסקה בדוק גרף, חדשות ודוחות.")


# ════════════════════════════ התראות ════════════════════════════
def _headline(row: dict) -> tuple[str, str]:
    ev, pos = row["ev"], row["pos"]
    if pos["status"] == "held":
        if ev.held_exit:
            return "bad", f"יציאה אותתה בנר {ev.held_exit_date}"
        if ev.held_surge_date:
            return "warn", f"קפיצה ({ev.held_surge_date}) · יציאה רק מתחת ל-MA6"
        return "neutral", "מחזיק · אין סימן יציאה"
    return ev.tone, ev.label


def _alert_board(p: core.Params) -> None:
    auto = core.load_store()["notify"].get("auto", True)

    @st.fragment(run_every="5m" if auto else None)
    def board() -> None:
        store = core.load_store()
        if not store["positions"]:
            st.info("הרשימה ריקה. הוסף מניות בטופס למעלה, או מלשונית הבדיקה והסורק.")
            return
        with st.spinner("בודק את הרשימה…"):
            rows = core.check_positions(store, p, send=True)
        st.caption(f"נבדק לאחרונה {datetime.now():%H:%M:%S}" + (" · רענון אוטומטי כל 5 דקות כשהאפליקציה פתוחה" if auto else ""))
        for row in rows:
            pos = row["pos"]
            with st.container(border=True):
                a, b = st.columns([6, 1], vertical_alignment="center")
                held = pos["status"] == "held"
                if row["ev"] is None:
                    a.markdown(f"**{pos['symbol']}** · {row['error']}")
                else:
                    tone, text = _headline(row)
                    ev = row["ev"]
                    a.markdown(f"**{pos['symbol']}** · {'🟢 בפנים' if held else '👀 במעקב'} · {ev.price:,.2f} ({ev.dist:+.1f}% מהקו)")
                    a.markdown(f":{'green' if tone == 'good' else 'red' if tone == 'bad' else 'orange' if tone == 'warn' else 'gray'}[{text}]")
                    extra = []
                    if held and pos.get("since"):
                        extra.append(f"מאז {pos['since']}")
                    if held and pos.get("entry_price"):
                        extra.append(f"כניסה {pos['entry_price']:,.2f} ({(ev.price / pos['entry_price'] - 1) * 100:+.1f}%)")
                    if row["sent"]:
                        extra.append("נשלחה התראה: " + ", ".join(row["sent"]))
                    elif pos.get("last_alert"):
                        extra.append("התראה אחרונה: " + pos["last_alert"])
                    if extra:
                        a.caption(" · ".join(extra))
                if b.button("", icon=":material/delete:", key=f"del_{pos['symbol']}", help="הסר מהרשימה"):
                    core.remove_position(store, pos["symbol"])
                    core.save_store(store)
                    st.rerun()

    board()


def _notify_settings(store: dict) -> None:
    n = store["notify"]
    with st.expander("הגדרות התראות", icon=":material/settings:"):
        n["enabled"] = st.toggle("שלח התראות", value=n.get("enabled", True), key="nt_enabled")
        n["auto"] = st.toggle("רענון אוטומטי כל 5 דקות כשהאפליקציה פתוחה", value=n.get("auto", True), key="nt_auto")
        c1, c2 = st.columns([4, 1], vertical_alignment="bottom")
        st.session_state.setdefault("nt_topic", n.get("ntfy_topic", ""))
        n["ntfy_topic"] = c1.text_input("נושא ntfy (חינמי, מגיע לפוש בטלפון)", key="nt_topic", placeholder="swing-xxxxxxxx")
        if c2.button("צור", icon=":material/casino:", help="יוצר נושא אקראי קשה לניחוש"):
            st.session_state["nt_topic"] = "swing-" + secrets.token_urlsafe(8)
            st.rerun()
        st.caption("מתקינים את אפליקציית ntfy (iOS/Android), נרשמים לנושא, ומקבלים פוש. הנושא הוא ה״סיסמה״ — השתמש בנושא אקראי.")
        n["tg_token"] = st.text_input("Telegram Bot Token (אופציונלי)", value=n.get("tg_token", ""), type="password", key="nt_tgt")
        n["tg_chat"] = st.text_input("Telegram Chat ID (אופציונלי)", value=n.get("tg_chat", ""), key="nt_tgc")
        s1, s2 = st.columns(2)
        if s1.button("שמור", icon=":material/save:", width="stretch", key="nt_save"):
            core.save_store(store)
            st.toast("ההגדרות נשמרו", icon=":material/check_circle:")
        if s2.button("שלח הודעת בדיקה", icon=":material/send:", width="stretch", key="nt_test"):
            cfg = core.notify_config(store)
            if not core.has_channel(cfg):
                st.warning("לא הוגדר ערוץ התראות.")
            else:
                st.info(" · ".join(core.send_notification(cfg, "✅ בדיקה · Swing & Pivot", "ההתראות עובדות.", 3, ("white_check_mark",))))
        st.caption("בלי worker, ההתראות נשלחות רק כשהאפליקציה פתוחה. להתראות גם כשהיא סגורה: alerts_worker.py (ראה README).")


def _tab_alerts(store: dict, p: core.Params) -> None:
    with st.form("add_pos", clear_on_submit=True):
        c1, c2 = st.columns(2)
        sym = core.clean_symbol(c1.text_input("סימול", placeholder="NVDA"))
        status = c2.radio("מצב", ["במעקב (מחכה לכניסה)", "אני בפנים (מחכה ליציאה)"], horizontal=True)
        c3, c4 = st.columns(2)
        price = c3.number_input("מחיר כניסה (אם בפנים)", min_value=0.0, value=0.0, step=0.1)
        since = c4.date_input("בפנים מאז", value=date.today(), max_value=date.today())
        if st.form_submit_button("הוסף לרשימה", icon=":material/add:", width="stretch") and sym:
            held = status.startswith("אני")
            core.upsert_position(store, sym, "held" if held else "watch", entry_price=price or None, since=since.isoformat() if held else None)
            core.save_store(store)
            st.toast(f"{sym} נוספה", icon=":material/check_circle:")
            st.rerun()
    _alert_board(p)
    _notify_settings(store)
    if store.get("log"):
        with st.expander("יומן התראות אחרונות", icon=":material/history:"):
            st.dataframe(pd.DataFrame(store["log"][::-1]), hide_index=True, width="stretch")


# ════════════════════════════ בקטסט ════════════════════════════
def _tab_backtest(p: core.Params, dev: dict) -> None:
    st.caption("סימולציה של הכללים על העבר: אות בסגירת הנר, ביצוע בפתיחת הנר הבא, עמלה 0.05% לכל צד. אין הבטחה לעתיד.")
    c1, c2 = st.columns([2, 1], vertical_alignment="bottom")
    sym = ui.symbol_input("סימול", "bt_sym", "AAPL")
    period = c2.segmented_control("טווח", ["2y", "5y", "10y"], default="5y", key="bt_period") or "5y"
    if not sym:
        return
    with st.spinner("מריץ בקטסט…"):
        df = core.download_ohlc((sym,), period).get(sym)
        res = core.backtest(df, p) if df is not None else None
    if res is None:
        st.warning("אין מספיק נתונים לבקטסט.")
        return
    st.plotly_chart(ui.equity_chart(res, ui.chart_height(dev, 380)), width="stretch", config=ui.PLOT_CFG)
    st.dataframe(res["stats"], width="stretch")
    tr = res["trades"]
    if tr.empty:
        st.info("הכללים לא יצרו עסקאות בטווח הזה.")
    else:
        st.markdown(f"##### עסקאות · {len(tr)}")
        st.dataframe(tr, hide_index=True, width="stretch",
                     column_config={"תשואה %": st.column_config.NumberColumn(format="%+.1f%%"),
                                    "מחיר כניסה": st.column_config.NumberColumn(format="%.2f"),
                                    "מחיר יציאה": st.column_config.NumberColumn(format="%.2f")})
    st.caption("שים לב: מניה אחת ותקופה אחת הן מדגם קטן. בדוק כמה מניות וכמה תקופות לפני שמסיקים מסקנות.")


# ════════════════════════════ כללים ════════════════════════════
def _reset_params() -> None:
    d = asdict(core.Params())
    for k, v in d.items():
        st.session_state[f"p_{k}"] = v


def _tab_rules(store: dict, dev: dict) -> None:
    n = st.session_state["p_ma_len"]
    st.markdown(
        f"**קנייה:** נר ירוק · סגירה מעל MA{n} · הנר לא נוגע בממוצע · עד {st.session_state['p_max_dist']:g}% מהקו  \n"
        f"**מכירה:** נר אדום · סגירה מתחת ל-MA{n} · הנר לא נוגע בממוצע  \n"
        f"**קפיצה:** {st.session_state['p_surge_days']} נרות ירוקים רצופים ועלייה של מעל {st.session_state['p_surge_pct']:g}% "
        f"← מוסיפים MA{st.session_state['p_fast_len']} ומוכרים רק בנר אדום מתחתיו")
    a, b = st.columns(2)
    a.number_input("ממוצע ראשי (ימים)", min_value=10, max_value=200, step=1, key="p_ma_len")
    b.number_input("מרחק מקסימלי מהקו (%)", min_value=0.5, max_value=20.0, step=0.5, key="p_max_dist")
    c, d = st.columns(2)
    c.number_input("ממוצע מהיר (ימים)", min_value=2, max_value=30, step=1, key="p_fast_len")
    d.number_input("נרות ירוקים רצופים לקפיצה", min_value=2, max_value=10, step=1, key="p_surge_days")
    e, f = st.columns(2)
    e.number_input("עלייה מצטברת לקפיצה (%)", min_value=5.0, max_value=100.0, step=1.0, key="p_surge_pct")
    f.toggle("MA מהיר: נר שלא נוגע בקו (מחמיר)", key="p_strict_fast",
             help="כבוי: מספיק נר אדום שנסגר מתחת ל-MA6. פעיל: כל הנר (גם השיא) מתחת לקו.")
    st.toggle("להתבסס על נרות סגורים בלבד", key="p_closed_only", help="נר היום באמצע מסחר לא נספר, כדי למנוע אותות שווא.")
    st.button("איפוס לברירת מחדל", icon=":material/restart_alt:", on_click=_reset_params)
    cur = {f_: st.session_state[f"p_{f_}"] for f_ in asdict(core.Params())}
    if cur != store.get("params"):
        store["params"] = cur
        core.save_store(store)

    with st.expander("איך פירשתי את הכללים", icon=":material/info:"):
        st.markdown(
            "- **״עד 4% מהקו״**: נמדד מסגירת הנר אל הממוצע.\n"
            "- **״לא נוגע״**: בקנייה — השפל של הנר מעל הממוצע; במכירה — השיא של הנר מתחת לממוצע.\n"
            "- **קפיצה**: כל הנרות ירוקים (סגירה מעל פתיחה) והעלייה נמדדת מהסגירה שלפני הרצף עד הסגירה האחרונה.\n"
            "- **MA6**: ברגע הקפיצה היציאה עוברת מ-MA50 ל-MA6 (נר אדום שנסגר מתחתיו) ונשארת כך עד היציאה.\n"
            "- אם התכוונת למשהו אחר, שנה כאן — כל המסכים והבקטסט מתעדכנים מיד.")
    with st.expander("התקנה כאפליקציה במכשיר", icon=":material/install_mobile:"):
        st.write(f"מזוהה: {dev['os']} · {dict(phone='טלפון', tablet='טאבלט', desktop='מחשב')[dev['kind']]}")
        st.write(ui.install_hint(dev))
    with st.expander("מצב מקורות המידע", icon=":material/monitor_heart:"):
        ui.health_panel()
