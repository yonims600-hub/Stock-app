"""
Swing & Pivot 2.0 · נקודת הכניסה של האפליקציה.
הרצה:  streamlit run app.py
"""
import streamlit as st

st.set_page_config(page_title="Swing & Pivot", page_icon="🎯", layout="wide", initial_sidebar_state="collapsed")

import assistant_view  # noqa: E402
import pivot_view  # noqa: E402
import swing_view  # noqa: E402
import ui  # noqa: E402

ui.inject_css()

PAGES = [
    st.Page(swing_view.render, title="סווינג", icon=":material/candlestick_chart:", url_path="swing", default=True),
    st.Page(pivot_view.render, title="מתחת לרדאר", icon=":material/radar:", url_path="pivot"),
    st.Page(assistant_view.render, title="עוזר AI", icon=":material/smart_toy:", url_path="assistant"),
]
current = st.navigation(PAGES, position="hidden")

# תפריט ראשי: בטלפון סרגל תחתון קבוע (כמו iOS), במחשב פס עליון.
with st.container(key="navbar"):
    for col, page in zip(st.columns(len(PAGES)), PAGES):
        col.page_link(page, width="stretch")

current.run()
