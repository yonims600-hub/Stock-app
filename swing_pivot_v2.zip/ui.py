"""
ui.py · רכיבי ממשק משותפים: עיצוב בסגנון Apple, זיהוי מכשיר/מערכת הפעלה, גרפים וכרטיסים.
"""
from __future__ import annotations

import html
from dataclasses import fields

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

import core
import datahub

GREEN, RED, BLUE, AMBER, GRAY = "#30d158", "#ff453a", "#0a84ff", "#ff9f0a", "#8e8e93"
PLOT_CFG = {"displayModeBar": False, "scrollZoom": True, "responsive": True}
FONT = '-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, "Heebo", Arial, sans-serif'

CSS = """
<style>
:root{--blue:#0a84ff;--green:#30d158;--red:#ff453a;--orange:#ff9f0a;--gray:#8e8e93;
  --card:rgba(128,128,128,.10);--stroke:rgba(128,128,128,.22);--r:18px}
html,body,.stApp,.stApp p,.stApp label,.stApp li,.stApp input,.stApp textarea,.stApp button,.stApp h1,.stApp h2,.stApp h3,.stApp h4{
  font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Pro Display","Segoe UI",Roboto,"Heebo","Noto Sans Hebrew","Helvetica Neue",Arial,sans-serif;
  -webkit-font-smoothing:antialiased;-webkit-text-size-adjust:100%}
.stApp{direction:rtl;-webkit-tap-highlight-color:transparent;touch-action:manipulation}
.stApp .stMarkdown,.stApp label,.stApp h1,.stApp h2,.stApp h3,.stApp h4{text-align:right}
.js-plotly-plot,[data-testid="stDataFrame"],code,.ltr{direction:ltr;text-align:left}
[data-testid="stSidebar"],[data-testid="stSidebarCollapsedControl"],#MainMenu,footer,.stAppDeployButton,[data-testid="stToolbar"]{display:none!important}
header[data-testid="stHeader"]{background:transparent;height:0}
.block-container{padding-top:1.2rem;padding-bottom:120px;max-width:1180px}
h1{font-size:2.15rem!important;font-weight:800!important;letter-spacing:-.02em;margin-bottom:.1rem}
h2,h3{letter-spacing:-.01em;font-weight:700!important}
input,textarea,select{font-size:16px!important}
button,[role=tab],[data-baseweb=tab]{min-height:44px}
.stButton>button,.stDownloadButton>button,.stLinkButton>a{border-radius:12px;font-weight:600}
div[data-testid="stMetric"]{background:var(--card);border:1px solid var(--stroke);border-radius:var(--r);padding:12px 16px}
div[data-testid="stMetricValue"]{font-size:1.5rem;font-weight:700;direction:ltr;text-align:right}
div[data-testid="stVerticalBlockBorderWrapper"]{border-radius:var(--r)}
.stTabs [data-baseweb="tab-list"]{gap:4px;background:var(--card);padding:4px;border-radius:14px;overflow-x:auto}
.stTabs [data-baseweb="tab"]{border-radius:10px;height:40px;padding:0 14px;white-space:nowrap}
.stTabs [aria-selected="true"]{background:rgba(128,128,128,.24)}
.stTabs [data-baseweb="tab-highlight"],.stTabs [data-baseweb="tab-border"]{display:none}
.sig{border-radius:var(--r);padding:16px 18px;margin:8px 0 14px;border:1px solid var(--stroke);background:var(--card)}
.sig .t{font-size:1.25rem;font-weight:800}.sig .s{opacity:.72;font-size:.9rem;margin-top:2px}
.sig.good{background:rgba(48,209,88,.14);border-color:rgba(48,209,88,.55)}
.sig.bad{background:rgba(255,69,58,.13);border-color:rgba(255,69,58,.55)}
.sig.warn{background:rgba(255,159,10,.14);border-color:rgba(255,159,10,.55)}
.cond{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-bottom:1px solid var(--stroke)}
.cond:last-child{border-bottom:none}
.ci{flex:0 0 24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.8rem;color:#fff}
.ci.ok{background:var(--green)}.ci.no{background:var(--red)}.ci.na{background:var(--gray)}
.cond b{display:block}.cond small{opacity:.68}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 10px}
.chip{padding:4px 11px;border-radius:999px;font-size:.8rem;font-weight:600;background:var(--card);border:1px solid var(--stroke)}
.chip.good{color:var(--green)}.chip.bad{color:var(--red)}.chip.warn{color:var(--orange)}
.steps{display:flex;gap:6px;margin:6px 0 12px}
.step{flex:1;text-align:center;padding:8px 4px;border-radius:12px;font-size:.78rem;background:var(--card);border:1px solid var(--stroke);opacity:.6}
.step.on{opacity:1;border-color:var(--blue);background:rgba(10,132,255,.14);font-weight:700}
.step.sweet{border-style:dashed}
.st-key-navbar{position:sticky;top:0;z-index:50;margin-bottom:6px}
.st-key-navbar [data-testid="stHorizontalBlock"]{background:var(--card);border:1px solid var(--stroke);border-radius:16px;padding:4px;gap:4px;flex-wrap:nowrap!important;flex-direction:row!important}
.st-key-navbar [data-testid="stColumn"]{min-width:0!important;flex:1 1 0!important}
.st-key-navbar a{justify-content:center;border-radius:12px;min-height:44px;font-weight:600}
@media (max-width:768px){
  .st-key-navbar{position:fixed;bottom:0;left:0;right:0;top:auto;z-index:1000;margin:0;padding:8px 12px calc(8px + env(safe-area-inset-bottom));
    background:rgba(250,250,252,.78);backdrop-filter:blur(24px) saturate(180%);-webkit-backdrop-filter:blur(24px) saturate(180%);border-top:1px solid var(--stroke)}
  h1{font-size:1.75rem!important}div[data-testid="stMetricValue"]{font-size:1.2rem}
  .block-container{padding-left:.9rem;padding-right:.9rem}
}
@media (max-width:768px) and (prefers-color-scheme:dark){.st-key-navbar{background:rgba(28,28,30,.78)}}
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


# ════════════════════════════ מכשיר ומערכת הפעלה ════════════════════════════
def detect_device() -> dict:
    ua = ""
    try:
        ua = (st.context.headers.get("User-Agent") or "").lower()
    except Exception:
        pass
    if "iphone" in ua or "ipod" in ua:
        os_, kind = "iOS", "phone"
    elif "ipad" in ua:
        os_, kind = "iPadOS", "tablet"
    elif "android" in ua:
        os_, kind = "Android", ("phone" if "mobile" in ua else "tablet")
    elif "windows" in ua:
        os_, kind = "Windows", "desktop"
    elif "mac os x" in ua or "macintosh" in ua:
        os_, kind = "macOS", "desktop"
    elif "linux" in ua or "cros" in ua:
        os_, kind = "Linux", "desktop"
    else:
        os_, kind = "Unknown", "desktop"
    return {"os": os_, "kind": kind, "phone": kind == "phone"}


def chart_height(dev: dict, base: int = 620) -> int:
    return {"phone": int(base * 0.66), "tablet": int(base * 0.85)}.get(dev["kind"], base)


def install_hint(dev: dict) -> str:
    return {
        "iOS": "ב-Safari: לחץ על כפתור השיתוף ← ״הוסף למסך הבית״. האפליקציה תיפתח במסך מלא כמו אפליקציה רגילה.",
        "iPadOS": "ב-Safari: שיתוף ← ״הוסף למסך הבית״.",
        "Android": "ב-Chrome: תפריט ⋮ ← ״התקן אפליקציה״ או ״הוסף למסך הבית״.",
    }.get(dev["os"], "ב-Chrome/Edge: סמל ההתקנה בשורת הכתובת ← ״התקן״. ב-Safari במק: קובץ ← ״הוסף ל-Dock״.")


# ════════════════════════════ פרמטרים בסשן ════════════════════════════
def init_params(store: dict) -> None:
    saved = core.params_from_dict(store.get("params"))
    for f in fields(core.Params):
        st.session_state.setdefault(f"p_{f.name}", getattr(saved, f.name))
    for f in fields(core.PivotParams):
        st.session_state.setdefault(f"pv_{f.name}", getattr(core.PivotParams(), f.name))


def current_params() -> core.Params:
    return core.Params(**{f.name: st.session_state[f"p_{f.name}"] for f in fields(core.Params)})


def current_pivot_params() -> core.PivotParams:
    return core.PivotParams(**{f.name: st.session_state[f"pv_{f.name}"] for f in fields(core.PivotParams)})


def set_ctx(key: str, value: dict | None) -> None:
    """מעביר את ההערכה הנוכחית לעוזר ה-AI."""
    ctx = st.session_state.setdefault("assistant_ctx", {})
    ctx[key] = value


def symbol_input(label: str, key: str, default: str) -> str:
    st.session_state.setdefault(key, default)
    return core.clean_symbol(st.text_input(label, key=key, placeholder="לדוגמה: NVDA או NICE.TA"))


# ════════════════════════════ רכיבי HTML ════════════════════════════
def status_card(tone: str, title: str, sub: str = "") -> None:
    st.markdown(f'<div class="sig {tone}"><div class="t">{html.escape(title)}</div>'
                f'<div class="s">{html.escape(sub)}</div></div>', unsafe_allow_html=True)


def cond_rows(conds: list) -> None:
    rows = "".join(
        f'<div class="cond"><span class="ci {"ok" if ok else "no"}">{"✓" if ok else "✕"}</span>'
        f'<div><b>{html.escape(label)}</b><small>{html.escape(detail)}</small></div></div>'
        for label, ok, detail in conds)
    st.markdown(rows, unsafe_allow_html=True)


def chips(items: list[tuple[str, str]]) -> None:
    st.markdown('<div class="chips">' + "".join(f'<span class="chip {t}">{html.escape(x)}</span>' for x, t in items) + "</div>",
                unsafe_allow_html=True)


def maturity_steps(active: int) -> None:
    cells = "".join(f'<div class="step {"on" if i == active else ""} {"sweet" if i in (2, 3) else ""}">{i}<br>{html.escape(t)}</div>'
                    for i, t in core.MATURITY.items())
    st.markdown(f'<div class="steps">{cells}</div>', unsafe_allow_html=True)
    st.caption("שלבים 2–3 (מסומנים בקו מקווקו) הם המעניינים ביותר להשקעה מתחת לרדאר.")


def health_panel() -> None:
    snap = datahub.HEALTH.snapshot()
    if not snap:
        st.caption("עדיין לא בוצעו קריאות לרשת.")
        return
    st.dataframe(pd.DataFrame(snap), hide_index=True, width="stretch")
    st.caption("מקורות: Yahoo Finance (ראשי) · Stooq (גיבוי מחירים) · SEC EDGAR (Form 4 ו-8-K רשמיים) · RSS של Yahoo ו-Google News. "
               "מקור שנכשל שוב ושוב מושהה אוטומטית והאפליקציה ממשיכה על נתוני גיבוי/מטמון.")


def src_caption(symbol: str) -> None:
    src = datahub.SOURCE_OF.get(symbol)
    if src:
        st.caption(f"מקור המחירים: {src}")


# ════════════════════════════ גרפים ════════════════════════════
def _style(fig: go.Figure, height: int) -> go.Figure:
    fig.update_layout(height=height, margin=dict(l=6, r=6, t=18, b=6), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", font=dict(color=GRAY, family=FONT, size=12),
                      hovermode="x unified", dragmode="pan", showlegend=False, xaxis_rangeslider_visible=False)
    fig.update_xaxes(gridcolor="rgba(128,128,128,.14)", showspikes=False)
    fig.update_yaxes(gridcolor="rgba(128,128,128,.14)", side="right")
    return fig


def swing_chart(d: pd.DataFrame, p: core.Params, bars: int, height: int, show_fast: bool) -> go.Figure:
    events, _, _ = core.run_state(d)
    x0 = d.index[max(len(d) - bars, 0)]
    v = d[d.index >= x0]
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.78, 0.22], vertical_spacing=0.03)
    fig.add_trace(go.Candlestick(x=v.index, open=v.Open, high=v.High, low=v.Low, close=v.Close, name="מחיר",
                                 increasing_line_color=GREEN, decreasing_line_color=RED,
                                 increasing_fillcolor=GREEN, decreasing_fillcolor=RED), 1, 1)
    fig.add_trace(go.Scatter(x=v.index, y=v["MA"], name=f"MA{p.ma_len}", line=dict(color=BLUE, width=2.2)), 1, 1)
    fig.add_trace(go.Scatter(x=v.index, y=v["MA"] * (1 + p.max_dist / 100), name="גבול כניסה",
                             line=dict(color="rgba(48,209,88,.6)", width=1, dash="dot"),
                             fill="tonexty", fillcolor="rgba(48,209,88,.09)"), 1, 1)
    if show_fast:
        fig.add_trace(go.Scatter(x=v.index, y=v["MAF"], name=f"MA{p.fast_len}", line=dict(color=AMBER, width=1.6)), 1, 1)
    marks = {"entry": ("triangle-up", GREEN, "Low", 0.985), "exit": ("triangle-down", RED, "High", 1.015),
             "surge": ("star", AMBER, "High", 1.03)}
    for kind, (sym, col, price_col, k) in marks.items():
        idx = [d.index[i] for i, kd, _m in events if kd == kind and d.index[i] >= x0]
        if idx:
            fig.add_trace(go.Scatter(x=idx, y=d.loc[idx, price_col] * k, mode="markers", name=kind,
                                     marker=dict(symbol=sym, size=11, color=col, line=dict(width=1, color="white"))), 1, 1)
    fig.add_trace(go.Bar(x=v.index, y=v.Volume, marker_color=np.where(v.Close >= v.Open, "rgba(48,209,88,.55)", "rgba(255,69,58,.55)")), 2, 1)
    fig.update_xaxes(rangebreaks=[dict(bounds=["sat", "mon"])])
    return _style(fig, height)


def equity_chart(res: dict, height: int) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=res["equity"].index, y=res["equity"], name="השיטה", line=dict(color=AMBER, width=2.4)))
    fig.add_trace(go.Scatter(x=res["bh"].index, y=res["bh"], name="קנה והחזק", line=dict(color=BLUE, width=1.6)))
    fig.update_layout(showlegend=True, legend=dict(orientation="h", y=1.1))
    return _style(fig, height).update_layout(showlegend=True)


def gauge_chart(value: float | None, height: int = 210) -> go.Figure:
    v = 0 if value is None else float(value)
    col = GREEN if v >= 70 else AMBER if v >= 50 else RED
    fig = go.Figure(go.Indicator(mode="gauge+number", value=v, number=dict(suffix="", font=dict(size=40, color=col)),
                                 gauge=dict(axis=dict(range=[0, 100], tickcolor=GRAY), bar=dict(color=col, thickness=0.28),
                                            bgcolor="rgba(128,128,128,.14)", borderwidth=0,
                                            steps=[dict(range=[0, 50], color="rgba(255,69,58,.10)"),
                                                   dict(range=[50, 70], color="rgba(255,159,10,.10)"),
                                                   dict(range=[70, 100], color="rgba(48,209,88,.10)")])))
    fig.update_layout(height=height, margin=dict(l=18, r=18, t=18, b=0), paper_bgcolor="rgba(0,0,0,0)", font=dict(family=FONT))
    return fig


def radar_chart(parts: dict, height: int = 330) -> go.Figure:
    names = [v["title"] for v in parts.values()]
    vals = [v["score"] or 0 for v in parts.values()]
    fig = go.Figure(go.Scatterpolar(r=vals + vals[:1], theta=names + names[:1], fill="toself", line=dict(color=BLUE, width=2),
                                    fillcolor="rgba(10,132,255,.22)", hovertemplate="%{theta}: %{r:.0f}<extra></extra>"))
    fig.update_layout(height=height, margin=dict(l=40, r=40, t=20, b=20), paper_bgcolor="rgba(0,0,0,0)", showlegend=False,
                      font=dict(color=GRAY, family=FONT, size=11),
                      polar=dict(bgcolor="rgba(0,0,0,0)", radialaxis=dict(range=[0, 100], gridcolor="rgba(128,128,128,.2)", tickfont=dict(size=9)),
                                 angularaxis=dict(gridcolor="rgba(128,128,128,.2)")))
    return fig


def pivot_chart(df: pd.DataFrame, m: dict, height: int) -> go.Figure:
    w = df["Close"].resample("W").last().dropna()
    fig = go.Figure(go.Scatter(x=w.index, y=w, name="סגירה שבועית", line=dict(color=BLUE, width=2),
                               fill="tozeroy", fillcolor="rgba(10,132,255,.07)"))
    fig.add_shape(type="rect", x0=m["flat_start"], x1=w.index[-1], y0=m["flat_lo"], y1=m["flat_hi"],
                  fillcolor="rgba(255,159,10,.14)", line=dict(color=AMBER, width=1, dash="dot"))
    fig.add_annotation(x=m["flat_start"], y=m["flat_hi"], text=f"דשדוש {m['flat_days'] / 252:.1f} שנים", showarrow=False,
                       xanchor="left", yanchor="bottom", font=dict(color=AMBER, size=11))
    fig.add_hline(y=m["hi3"], line=dict(color=GRAY, width=1, dash="dot"), annotation_text="שיא 3 שנים", annotation_position="top left")
    rows = m["ins"].get("rows")
    if rows is not None and "Start Date" in rows:
        dts = pd.to_datetime(rows["Start Date"], errors="coerce").dropna()
        if len(dts):
            ys = [float(df["Close"].asof(t)) for t in dts]
            fig.add_trace(go.Scatter(x=dts, y=ys, mode="markers", name="קניית אינסיידר",
                                     marker=dict(symbol="triangle-up", size=12, color=GREEN, line=dict(width=1, color="white"))))
    return _style(fig, height)


def fundamentals_chart(deep: dict, height: int) -> go.Figure | None:
    rev = deep.get("rev")
    if rev is None or len(rev) < 2:
        return None
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.07,
                        subplot_titles=("הכנסות רבעוניות ($M)", "תזרים חופשי רבעוני ($M)", "שולי רווח גולמי (%)"))
    fig.add_trace(go.Bar(x=rev.index, y=rev / 1e6, marker_color=BLUE), 1, 1)
    fcf = deep.get("fcf")
    if fcf is not None and len(fcf):
        fig.add_trace(go.Bar(x=fcf.index, y=fcf / 1e6, marker_color=np.where(fcf >= 0, GREEN, RED)), 2, 1)
    gm = deep.get("gm")
    if gm is not None and len(gm):
        fig.add_trace(go.Scatter(x=gm.index, y=gm, mode="lines+markers", line=dict(color=AMBER, width=2)), 3, 1)
    fig.update_annotations(font=dict(size=12, color=GRAY))
    return _style(fig, height).update_layout(hovermode="x")
