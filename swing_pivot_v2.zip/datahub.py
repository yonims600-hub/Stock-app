"""
datahub.py · שכבת הנתונים העמידה של Swing & Pivot 2.0

עקרונות:
  1. אף מקור חיצוני לא יכול להפיל את האפליקציה: כל קריאה עטופה, ובכישלון חוזרים לנתון האחרון שהיה תקין (stale)
     או למקור חלופי. אם אין כלום מחזירים ערך ריק נקי, והממשק מציג מחוון ״אין נתונים״.
  2. מכבדים את המקורות ולא עוקפים אותם: מטמון זיכרון+דיסק, הגבלת קצב לכל מארח, backoff מעריכי עם jitter,
     כיבוד Retry-After, וקוצץ-מעגל (circuit breaker) שמשהה מקור אחרי כשלונות חוזרים.
     ל-SEC EDGAR מזדהים בשם אמיתי (SEC_USER_AGENT) כנדרש במדיניות ה-Fair Access שלהם.
  3. עושר מידע בלי תלות במפתחות: Yahoo (ראשי) ← Stooq (גיבוי מחירים) ← SEC EDGAR (Form 4 + דיווחי 8-K רשמיים)
     ← RSS של Yahoo ו-Google News. Finnhub אופציונלי אם הוגדר FINNHUB_API_KEY.

אין כאן תלות ב-Streamlit.
"""
from __future__ import annotations

import functools
import hashlib
import io
import itertools
import os
import pickle
import random
import re
import threading
import time
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import quote_plus
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import requests
import yfinance as yf

DATA_DIR = Path(os.getenv("SWING_DATA_DIR", Path(__file__).parent / "data"))
CACHE_DIR = DATA_DIR / "cache"
DEFAULT_TZ = "America/New_York"
CLOSE_HOUR = {"America/New_York": 16.0, "Asia/Jerusalem": 17.5, "Europe/London": 16.5}
SEC_UA = os.getenv("SEC_USER_AGENT", "SwingPivotApp/2.0 (research; set SEC_USER_AGENT=\"Name email@domain\")")
PERIOD_DAYS = {"1mo": 31, "3mo": 93, "6mo": 186, "1y": 366, "2y": 731, "5y": 1827, "10y": 3653, "max": 9000}
SOURCE_OF: dict[str, str] = {}  # סימול ← מקור המחירים שבו נעשה שימוש

# 8-K: סעיפים רלוונטיים לתזת הפיבוט
ITEM_TAGS = {
    "5.02": "mgmt",          # עזיבה/מינוי של דירקטורים וקצינים בכירים
    "1.01": "agreement",     # כניסה להסכם מהותי (שותף/לקוח)
    "1.02": "termination",   # ביטול הסכם מהותי
    "2.01": "mna",           # רכישה/מכירה של נכסים
    "2.05": "restructuring",  # עלויות יציאה/הפסקת פעילות
    "2.06": "impairment",    # פגיעת ערך מהותית
    "3.02": "dilution",      # הנפקת הון לא רשומה (דילול)
    "4.02": "restatement",   # אי-הסתמכות על דוחות קודמים
    "1.03": "bankruptcy",
    "3.01": "delisting",
}
EVENT_TAGS = tuple(dict.fromkeys(ITEM_TAGS.values()))
EVENT_LABELS = {
    "mgmt": "שינוי הנהלה/דירקטוריון", "agreement": "הסכם מהותי חדש", "termination": "ביטול הסכם מהותי",
    "mna": "רכישה/מכירת נכסים", "restructuring": "ארגון מחדש/סגירת פעילות", "impairment": "פגיעת ערך",
    "dilution": "הנפקת הון (דילול)", "restatement": "תיקון דוחות כספיים", "bankruptcy": "פשיטת רגל",
    "delisting": "התראת מחיקה מהמסחר",
}
RED_FLAG_TAGS = ("restatement", "bankruptcy", "delisting")


# ════════════════════════════ בריאות מקורות + קוצץ מעגל ════════════════════════════
class Health:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.src: dict[str, dict] = defaultdict(lambda: {"ok": 0, "fail": 0, "consec": 0, "open_until": 0.0,
                                                          "last_ms": None, "last_err": None, "stale": 0, "trips": 0})

    def allowed(self, name: str) -> bool:
        with self.lock:
            return time.time() >= self.src[name]["open_until"]

    def ok(self, name: str, ms: float | None = None) -> None:
        with self.lock:
            s = self.src[name]
            s["ok"] += 1
            s["consec"] = 0
            s["last_ms"] = ms

    def fail(self, name: str, err: str, hard: bool = False) -> None:
        with self.lock:
            s = self.src[name]
            s["fail"] += 1
            s["consec"] += 1
            s["last_err"] = err
            if hard or s["consec"] >= 4:
                s["trips"] += 1
                s["open_until"] = time.time() + min(900, (600 if hard else 60) * (2 ** min(s["trips"] - 1, 3)))

    def note_stale(self, name: str) -> None:
        with self.lock:
            self.src["cache"]["stale"] += 1

    def snapshot(self) -> list[dict]:
        out = []
        with self.lock:
            for name, s in sorted(self.src.items()):
                if name == "cache":
                    continue
                paused = time.time() < s["open_until"]
                state = "מושהה" if paused else ("תקין" if s["consec"] == 0 else "חלקי")
                out.append({"מקור": name, "מצב": state, "הצלחות": s["ok"], "כשלונות": s["fail"],
                            "זמן (ms)": None if s["last_ms"] is None else round(s["last_ms"]),
                            "שגיאה אחרונה": s["last_err"] or "—"})
        return out


HEALTH = Health()


# ════════════════════════════ מטמון זיכרון + דיסק, עם חזרה לנתון ישן ════════════════════════════
def _is_empty(val) -> bool:
    return val is None or (hasattr(val, "empty") and val.empty) or (isinstance(val, (dict, list, tuple)) and not val)


def ttl_cache(seconds: int, disk: bool = False, empty=lambda: None, neg_seconds: int = 90):
    """מטמון עם TTL. תוצאה ריקה נשמרת קצר (neg_seconds) כדי לא להכות שוב ושוב במקור;
    אם הקריאה נכשלה/ריקה ויש ערך ישן תקין - מחזירים אותו (graceful degradation)."""
    def deco(fn):
        mem: dict = {}
        lock = threading.Lock()

        def disk_path(key: str) -> Path:
            return CACHE_DIR / (hashlib.sha1(key.encode()).hexdigest() + ".pkl")

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            key = f"{fn.__module__}.{fn.__name__}:{args!r}:{sorted(kwargs.items())!r}"
            now = time.time()
            with lock:
                entry = mem.get(key)
            if entry is None and disk:
                try:
                    with open(disk_path(key), "rb") as f:
                        entry = pickle.load(f)
                    with lock:
                        mem[key] = entry
                except Exception:
                    entry = None
            if entry and now - entry[0] < (neg_seconds if entry[2] else seconds):
                return entry[1]
            try:
                val = fn(*args, **kwargs)
            except Exception:
                val = None
            if _is_empty(val):
                if entry and not entry[2]:
                    HEALTH.note_stale(fn.__name__)
                    return entry[1]
                val = empty() if val is None else val
                with lock:
                    mem[key] = (now, val, True)
                return val
            with lock:
                if len(mem) > 400:
                    mem.clear()
                mem[key] = (now, val, False)
            if disk:
                try:
                    CACHE_DIR.mkdir(parents=True, exist_ok=True)
                    with open(disk_path(key), "wb") as f:
                        pickle.dump((now, val, False), f)
                except Exception:
                    pass
            return val

        wrapper.clear = lambda: mem.clear()  # type: ignore[attr-defined]
        return wrapper
    return deco


# ════════════════════════════ לקוח HTTP מנומס ════════════════════════════
_UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
]
_PROXIES = [p.strip() for p in os.getenv("DATAHUB_PROXIES", "").split(",") if p.strip()]
_proxy_cycle = itertools.cycle(_PROXIES) if _PROXIES else None


class Http:
    """GET עם הגבלת קצב, backoff מעריכי + jitter, כיבוד Retry-After וחיבור לקוצץ המעגל."""

    def __init__(self, source: str, per_sec: float = 2.0, ua: str | None = None, retries: int = 3,
                 timeout: float = 12.0, use_proxies: bool = False) -> None:
        self.source, self.interval, self.fixed_ua = source, 1.0 / per_sec, ua
        self.retries, self.timeout, self.use_proxies = retries, timeout, use_proxies
        self.session = requests.Session()
        self._lock, self._last = threading.Lock(), 0.0

    def _wait(self) -> None:
        with self._lock:
            gap = self.interval - (time.time() - self._last)
            if gap > 0:
                time.sleep(gap)
            self._last = time.time()

    def get(self, url: str, params: dict | None = None, as_json: bool = False, as_bytes: bool = False):
        if not HEALTH.allowed(self.source):
            return None
        headers = {"User-Agent": self.fixed_ua or random.choice(_UAS), "Accept-Encoding": "gzip, deflate"}
        proxies = None
        if self.use_proxies and _proxy_cycle:
            p = next(_proxy_cycle)
            proxies = {"http": p, "https": p}
        for attempt in range(self.retries + 1):
            self._wait()
            t0 = time.time()
            try:
                r = self.session.get(url, params=params, headers=headers, timeout=self.timeout, proxies=proxies)
            except requests.RequestException as e:
                HEALTH.fail(self.source, type(e).__name__)
                time.sleep(min(6.0, 0.6 * 2 ** attempt + random.random() * 0.4))
                continue
            ms = (time.time() - t0) * 1000
            if r.status_code == 200:
                try:
                    out = r.json() if as_json else (r.content if as_bytes else r.text)
                except ValueError:
                    HEALTH.fail(self.source, "bad payload")
                    return None
                HEALTH.ok(self.source, ms)
                return out
            if r.status_code == 404:
                HEALTH.ok(self.source, ms)
                return None
            if r.status_code in (429, 500, 502, 503, 504):
                HEALTH.fail(self.source, f"HTTP {r.status_code}")
                try:
                    wait = float(r.headers.get("Retry-After", 0))
                except ValueError:
                    wait = 0.0
                time.sleep(min(10.0, max(wait, 0.8 * 2 ** attempt) + random.random() * 0.5))
                continue
            HEALTH.fail(self.source, f"HTTP {r.status_code}", hard=r.status_code in (401, 403))
            return None
        return None


_sec = Http("SEC EDGAR", per_sec=5, ua=SEC_UA, use_proxies=False)
_stooq = Http("Stooq", per_sec=1.0)
_rss = Http("RSS חדשות", per_sec=2.0)
_finnhub = Http("Finnhub", per_sec=1.0)


def _yf_call(fn, *args, **kwargs):
    """קריאה ל-yfinance מוגנת: שגיאה = None + רישום בריאות; לא מפילה את האפליקציה."""
    if not HEALTH.allowed("Yahoo Finance"):
        return None
    t0 = time.time()
    try:
        res = fn(*args, **kwargs)
    except Exception as e:  # כולל YFRateLimitError
        HEALTH.fail("Yahoo Finance", type(e).__name__)
        return None
    HEALTH.ok("Yahoo Finance", (time.time() - t0) * 1000)
    return res


# ════════════════════════════ עזרי סימול/זמן ════════════════════════════
def clean_symbol(s: str) -> str:
    return re.sub(r"[^A-Z0-9.\-^=]", "", (s or "").upper())[:15]


def tz_for(symbol: str) -> str:
    s = symbol.upper()
    return "Asia/Jerusalem" if s.endswith(".TA") else "Europe/London" if s.endswith(".L") else DEFAULT_TZ


def is_live(last_ts, tz: str) -> bool:
    """האם הנר היומי האחרון עדיין פתוח (באמצע מסחר)? הערכה לפי שעת סגירה של הבורסה."""
    try:
        now = datetime.now(ZoneInfo(tz))
    except Exception:
        return False
    if now.weekday() >= 5:
        return False
    return pd.Timestamp(last_ts).date() == now.date() and (now.hour + now.minute / 60) < CLOSE_HOUR.get(tz, 16.0)


# ════════════════════════════ מחירים: Yahoo ← Stooq ════════════════════════════
def _clean(sub: pd.DataFrame | None) -> pd.DataFrame | None:
    need = ["Open", "High", "Low", "Close"]
    if sub is None or sub.empty or any(c not in sub.columns for c in need):
        return None
    if "Volume" not in sub.columns:
        sub = sub.assign(Volume=0.0)
    sub = sub[need + ["Volume"]].dropna(subset=need).copy()
    sub["Volume"] = sub["Volume"].fillna(0.0)
    sub.index = pd.to_datetime(sub.index)
    if sub.index.tz is not None:
        sub.index = sub.index.tz_localize(None)
    sub = sub[~sub.index.duplicated()].sort_index()
    return sub if len(sub) >= 5 else None


def _split(raw, symbols: tuple) -> dict:
    out: dict = {}
    if raw is None or raw.empty:
        return out
    cols = raw.columns
    for s in symbols:
        try:
            if isinstance(cols, pd.MultiIndex):
                if s in cols.get_level_values(0):
                    sub = raw[s]
                elif s in cols.get_level_values(1):
                    sub = raw.xs(s, axis=1, level=1)
                else:
                    continue
            elif len(symbols) == 1:
                sub = raw
            else:
                continue
            sub = _clean(sub)
            if sub is not None:
                out[s] = sub
        except Exception:
            continue
    return out


def _stooq_symbol(s: str) -> str | None:
    return s.lower() + ".us" if re.fullmatch(r"[A-Z]{1,5}(-[A-Z])?", s) else None


def stooq_history(symbol: str, period: str = "2y") -> pd.DataFrame | None:
    code = _stooq_symbol(symbol)
    if not code:
        return None
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=PERIOD_DAYS.get(period, 731))
    txt = _stooq.get("https://stooq.com/q/d/l/", params={"s": code, "i": "d", "d1": start.strftime("%Y%m%d"),
                                                          "d2": end.strftime("%Y%m%d")})
    if not txt or not txt.lstrip().startswith("Date"):
        return None
    try:
        df = pd.read_csv(io.StringIO(txt), index_col="Date", parse_dates=True)
    except Exception:
        return None
    return _clean(df)


@ttl_cache(300, empty=dict)
def download_ohlc(symbols: tuple, period: str = "2y") -> dict:
    """נרות יומיים (מתואמים) לכמה סימולים בקריאה אחת; סימול שחסר מקבל גיבוי מ-Stooq."""
    symbols = tuple(dict.fromkeys(s for s in symbols if s))
    if not symbols:
        return {}
    raw = _yf_call(yf.download, list(symbols), period=period, interval="1d", auto_adjust=True,
                   group_by="ticker", progress=False, threads=True)
    out = _split(raw, symbols)
    for s in out:
        SOURCE_OF[s] = "Yahoo Finance"
    for s in [x for x in symbols if x not in out][:8]:
        df = stooq_history(s, period)
        if df is not None:
            out[s], SOURCE_OF[s] = df, "Stooq (גיבוי)"
    return out


@ttl_cache(20, empty=lambda: None)
def get_quote(symbol: str) -> dict | None:
    fi = _yf_call(lambda: yf.Ticker(symbol).fast_info)
    try:
        last, prev = float(fi["last_price"]), float(fi["previous_close"])
        return {"last": last, "prev": prev, "pct": (last / prev - 1) * 100, "src": "Yahoo Finance"}
    except Exception:
        pass
    df = download_ohlc((symbol,), "1y").get(symbol)  # גיבוי: שני הנרות האחרונים שכבר במטמון
    if df is not None and len(df) > 1:
        last, prev = float(df["Close"].iloc[-1]), float(df["Close"].iloc[-2])
        return {"last": last, "prev": prev, "pct": (last / prev - 1) * 100, "src": SOURCE_OF.get(symbol, "מטמון")}
    return None


# ════════════════════════════ פונדמנטלס ════════════════════════════
@ttl_cache(3600, disk=True, empty=dict)
def get_info(symbol: str) -> dict:
    info = _yf_call(lambda: yf.Ticker(symbol).get_info()) or {}
    if info:
        return info
    fi = _yf_call(lambda: yf.Ticker(symbol).fast_info)
    try:
        return {"marketCap": fi["market_cap"], "currentPrice": fi["last_price"], "shortName": symbol}
    except Exception:
        return {}


def _row(df, names: list[str]) -> pd.Series | None:
    if df is None or getattr(df, "empty", True):
        return None
    for n in names:
        if n in df.index:
            return pd.to_numeric(df.loc[n], errors="coerce").dropna().sort_index()
    return None


@ttl_cache(6 * 3600, disk=True, empty=dict)
def fundamentals_deep(symbol: str) -> dict:
    """ניתוח רבעוני: מגמת הכנסות, שולי רווח, שריפת מזומנים אמיתית (ממוצע 2 רבעונים), דילול. (סעיף 3 בתזה)"""
    try:
        t = yf.Ticker(symbol)
        inc = _yf_call(lambda: t.quarterly_income_stmt)
        cf = _yf_call(lambda: t.quarterly_cashflow)
        bs = _yf_call(lambda: t.quarterly_balance_sheet)
        rev = _row(inc, ["Total Revenue", "Operating Revenue"])
        if rev is None or len(rev) < 2:
            return {}
        gp = _row(inc, ["Gross Profit"])
        gm = (gp / rev * 100).dropna() if gp is not None else None
        yoy = ((rev / rev.shift(4) - 1) * 100).dropna() if len(rev) >= 5 else pd.Series(dtype=float)
        fcf = _row(cf, ["Free Cash Flow"])
        if fcf is None:
            ocf = _row(cf, ["Operating Cash Flow", "Cash Flow From Continuing Operating Activities"])
            capex = _row(cf, ["Capital Expenditure"])
            fcf = (ocf + capex).dropna() if ocf is not None and capex is not None else ocf
        cash_s = _row(bs, ["Cash Cash Equivalents And Short Term Investments", "Cash And Cash Equivalents"])
        shares = _row(bs, ["Ordinary Shares Number", "Share Issued"])
        cash = float(cash_s.iloc[-1]) if cash_s is not None and len(cash_s) else None
        runway = None
        if fcf is not None and len(fcf):
            recent = float(fcf.tail(2).mean())
            if recent >= 0:
                runway = 999.0
            elif cash is not None:
                runway = cash / (-recent / 3)
        dil = None
        if shares is not None and len(shares) >= 2 and shares.iloc[0] > 0:
            dil = float(shares.iloc[-1] / shares.iloc[0] - 1) * 100
        return {"rev": rev, "rev_yoy": yoy, "gm": gm, "fcf": fcf, "cash": cash, "runway": runway,
                "dilution_pct": dil, "rev_yoy_last": float(yoy.iloc[-1]) if len(yoy) else None,
                "gm_last": float(gm.iloc[-1]) if gm is not None and len(gm) else None}
    except Exception:
        return {}


# ════════════════════════════ SEC EDGAR: Form 4 ודיווחי 8-K ════════════════════════════
@ttl_cache(7 * 86400, disk=True, empty=dict)
def _sec_tickers() -> dict:
    data = _sec.get("https://www.sec.gov/files/company_tickers.json", as_json=True)
    if not isinstance(data, dict):
        return {}
    return {str(v["ticker"]).upper(): int(v["cik_str"]) for v in data.values()}


def sec_cik(symbol: str) -> int | None:
    return _sec_tickers().get(symbol.upper())


@ttl_cache(6 * 3600, disk=True, empty=dict)
def sec_submissions(cik: int) -> dict:
    data = _sec.get(f"https://data.sec.gov/submissions/CIK{int(cik):010d}.json", as_json=True)
    return data if isinstance(data, dict) else {}


def _recent_filings(symbol: str):
    cik = sec_cik(symbol)
    if not cik:
        return None, []
    rec = sec_submissions(cik).get("filings", {}).get("recent", {})
    keys = ("form", "filingDate", "accessionNumber", "primaryDocument", "items")
    cols = [rec.get(k, []) for k in keys]
    return cik, list(itertools.zip_longest(*cols, fillvalue=""))


@ttl_cache(6 * 3600, disk=True, empty=list)
def sec_events(symbol: str, days: int = 365) -> list[dict]:
    """אירועי 8-K מסווגים לפי סעיף (שינוי הנהלה, הסכמים מהותיים, רכישות/מכירות, דילול, דגלים אדומים...)."""
    cik, filings = _recent_filings(symbol)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
    out = []
    for form, d, acc, doc, items in filings:
        if form not in ("8-K", "8-K/A"):
            continue
        if d < cutoff:
            break
        lst = [x.strip() for x in str(items).split(",") if x.strip()]
        out.append({"date": d, "form": form, "items": lst, "tags": sorted({ITEM_TAGS[i] for i in lst if i in ITEM_TAGS}),
                    "url": f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace('-', '')}/{doc}"})
    return out


def _xml_text(node, path: str) -> str:
    el = node.find(path) if node is not None else None
    return (el.text or "").strip() if el is not None and el.text else ""


@ttl_cache(30 * 86400, disk=True, empty=list)
def _parse_form4(cik: int, acc: str, doc: str) -> list[dict]:
    raw_doc = re.sub(r"^xsl[^/]+/", "", doc)
    url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace('-', '')}/{raw_doc}"
    content = _sec.get(url, as_bytes=True)
    if not content:
        return []
    try:
        root = ET.fromstring(content)
    except ET.ParseError:
        return []
    owner = root.find("reportingOwner")
    name = _xml_text(owner, "reportingOwnerId/rptOwnerName")
    rel = owner.find("reportingOwnerRelationship") if owner is not None else None
    title = _xml_text(rel, "officerTitle")
    if not title and rel is not None:
        title = "Director" if _xml_text(rel, "isDirector") in ("1", "true") else (
            "10% Owner" if _xml_text(rel, "isTenPercentOwner") in ("1", "true") else "Insider")
    rows = []
    for tx in root.findall("nonDerivativeTable/nonDerivativeTransaction"):
        code = _xml_text(tx, "transactionCoding/transactionCode")
        if code not in ("P", "S"):
            continue
        try:
            shares = float(_xml_text(tx, "transactionAmounts/transactionShares/value") or 0)
        except ValueError:
            shares = 0.0
        try:
            px = float(_xml_text(tx, "transactionAmounts/transactionPricePerShare/value") or 0)
        except ValueError:
            px = 0.0
        word = "Purchase" if code == "P" else "Sale"
        rows.append({"Insider": name, "Position": title,
                     "Start Date": pd.to_datetime(_xml_text(tx, "transactionDate/value"), errors="coerce"),
                     "Shares": shares, "Value": shares * px if px else np.nan,
                     "Text": f"{word} at price {px:.2f} per share." if px else f"{word}.",
                     "Transaction": word, "URL": url, "Source": "SEC EDGAR"})
    return rows


@ttl_cache(3 * 3600, disk=True, empty=lambda: None)
def sec_form4(symbol: str, days: int = 180, max_filings: int = 20) -> pd.DataFrame | None:
    """עסקאות אינסיידרים (קנייה/מכירה בשוק הפתוח) ישירות מ-Form 4 הרשמי."""
    cik, filings = _recent_filings(symbol)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
    rows, n = [], 0
    for form, d, acc, doc, _items in filings:
        if form != "4":
            continue
        if d < cutoff or n >= max_filings:
            break
        n += 1
        rows += _parse_form4(cik, acc, doc)
    return pd.DataFrame(rows) if rows else None


# ════════════════════════════ Finnhub (אופציונלי) ════════════════════════════
def _finnhub_key() -> str:
    return os.getenv("FINNHUB_API_KEY", "")


def finnhub_insiders(symbol: str) -> pd.DataFrame | None:
    key = _finnhub_key()
    if not key:
        return None
    data = _finnhub.get("https://finnhub.io/api/v1/stock/insider-transactions",
                        params={"symbol": symbol, "token": key}, as_json=True)
    rows = []
    for x in (data or {}).get("data", []):
        code = x.get("transactionCode")
        if code not in ("P", "S"):
            continue
        px, sh = float(x.get("transactionPrice") or 0), abs(float(x.get("change") or 0))
        word = "Purchase" if code == "P" else "Sale"
        rows.append({"Insider": x.get("name"), "Position": "Insider", "Start Date": pd.to_datetime(x.get("transactionDate"), errors="coerce"),
                     "Shares": sh, "Value": sh * px if px else np.nan, "Text": f"{word} at price {px:.2f} per share.",
                     "Transaction": word, "URL": "", "Source": "Finnhub"})
    return pd.DataFrame(rows) if rows else None


@ttl_cache(3 * 3600, disk=True, empty=lambda: None)
def get_insiders(symbol: str):
    """עסקאות אינסיידרים: Yahoo ← SEC Form 4 ← Finnhub. הראשון שמחזיר נתונים מנצח."""
    df = _yf_call(lambda: yf.Ticker(symbol).insider_transactions)
    if df is not None and not df.empty:
        df = df.copy()
        df["Source"] = "Yahoo Finance"
        return df
    df = sec_form4(symbol)
    if df is not None and not df.empty:
        return df
    return finnhub_insiders(symbol)


# ════════════════════════════ חדשות: yfinance + RSS ════════════════════════════
def _norm_title(t: str) -> str:
    return re.sub(r"\W+", " ", t.lower()).strip()[:90]


def _to_naive_utc(dt) -> datetime | None:
    try:
        ts = pd.Timestamp(dt)
        if ts.tzinfo is not None:
            ts = ts.tz_convert("UTC").tz_localize(None)
        return ts.to_pydatetime()
    except Exception:
        return None


def _rss_items(xml_text: str | None, source: str) -> list[dict]:
    if not xml_text:
        return []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []
    out = []
    for it in root.iter("item"):
        title = (it.findtext("title") or "").strip()
        if not title:
            continue
        pub = it.findtext("pubDate")
        try:
            when = _to_naive_utc(parsedate_to_datetime(pub)) if pub else None
        except (TypeError, ValueError):
            when = None
        out.append({"title": title, "url": (it.findtext("link") or "").strip(),
                    "publisher": (it.findtext("source") or source).strip(), "time": when, "source": source})
    return out


@ttl_cache(900, empty=list)
def get_news(symbol: str, lang: str = "en") -> list[dict]:
    items: list[dict] = []
    for it in _yf_call(lambda: yf.Ticker(symbol).news) or []:
        c = it.get("content") or it
        url = (c.get("canonicalUrl") or {}).get("url") or (c.get("clickThroughUrl") or {}).get("url") or c.get("link") or ""
        when = c.get("pubDate") or c.get("providerPublishTime")
        if isinstance(when, (int, float)):
            when = datetime.fromtimestamp(when, timezone.utc)
        if c.get("title"):
            items.append({"title": c["title"], "url": url, "time": _to_naive_utc(when) if when else None,
                          "publisher": (c.get("provider") or {}).get("displayName") or c.get("publisher") or "Yahoo",
                          "source": "Yahoo Finance"})
    items += _rss_items(_rss.get("https://feeds.finance.yahoo.com/rss/2.0/headline",
                                 params={"s": symbol, "region": "US", "lang": "en-US"}), "Yahoo RSS")
    q = quote_plus(f"{symbol} stock")
    gl = "hl=he&gl=IL&ceid=IL:he" if lang == "he" else "hl=en-US&gl=US&ceid=US:en"
    items += _rss_items(_rss.get(f"https://news.google.com/rss/search?q={q}&{gl}"), "Google News")
    seen, out = set(), []
    for it in sorted(items, key=lambda x: x["time"] or datetime(1970, 1, 1), reverse=True):
        k = _norm_title(it["title"])
        if k not in seen:
            seen.add(k)
            out.append(it)
    return out[:30]
