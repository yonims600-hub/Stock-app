"""
alerts_worker.py · בדיקת התראות ברקע, בלי ממשק.

שימוש:
    python alerts_worker.py            # בדיקה אחת (מתאים ל-cron / GitHub Actions)
    python alerts_worker.py --loop 15  # בדיקה כל 15 דקות (שרת/מחשב שרץ תמיד)

משתמש באותם כללים ובאותו קובץ data/store.json כמו האפליקציה. כל אות נשלח פעם אחת בלבד.
ערוצים: NTFY_TOPIC / TELEGRAM_TOKEN + TELEGRAM_CHAT_ID (משתני סביבה) או מה ששמרת בלשונית ההתראות.
"""
import argparse
import sys
import time
from datetime import datetime

import core


def run_once() -> int:
    store = core.load_store()
    p = core.params_from_dict(store.get("params"))
    rows = core.check_positions(store, p, send=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    if not rows:
        print(f"[{stamp}] הרשימה ריקה")
        return 0
    for r in rows:
        pos = r["pos"]
        state = r["error"] or (r["ev"].label if r["ev"] else "—")
        print(f"[{stamp}] {pos['symbol']:<8} {pos['status']:<5} {state}"
              + (f" | אות: {r['kind']}" if r["kind"] else "") + (f" | נשלח: {', '.join(r['sent'])}" if r["sent"] else ""))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Swing & Pivot alerts worker")
    ap.add_argument("--loop", type=int, default=0, help="דקות בין בדיקות (0 = פעם אחת)")
    args = ap.parse_args()
    if not args.loop:
        return run_once()
    while True:
        try:
            run_once()
        except Exception as e:  # noqa: BLE001  ה-worker לא מת על שגיאה חד-פעמית
            print(f"שגיאה: {e}", file=sys.stderr)
        time.sleep(max(args.loop, 1) * 60)


if __name__ == "__main__":
    sys.exit(main())
