"""
assistant_view.py · עמוד 3: עוזר ה-AI — צ'אט עם סטרימינג, זיכרון שיחה והקשר אוטומטי מהמניה האחרונה שנבדקה.
"""
from __future__ import annotations

import streamlit as st

import assistant
import core
import ui

QUICK = ["הסבר את מצב המניה האחרונה", "מה חסר לנקודת כניסה?", "סכם את הפיבוט והסיכונים",
         "מה ההבדל בין MA50 ל-MA6 בשיטה?", "איך מפרשים רכישות אינסיידרים?"]


def _secret(key: str):
    try:
        return st.secrets.get(key)
    except Exception:
        return None


def _quick_pick() -> None:
    pick = st.session_state.get("chat_pills")
    if pick:
        st.session_state["chat_pending"] = pick
        st.session_state["chat_pills"] = None


def _settings() -> assistant.LLMConfig | None:
    ov = st.session_state.setdefault("llm_override", {})
    with st.expander("הגדרות AI", icon=":material/key:"):
        provs = list(assistant.PROVIDERS)
        prov = st.selectbox("ספק", provs, format_func=lambda k: assistant.PROVIDERS[k]["label"],
                            index=provs.index(ov.get("provider", "anthropic")), key="llm_prov")
        meta = assistant.PROVIDERS[prov]
        model = st.text_input("מודל", value=ov.get("model") or _secret(meta["model_env"]) or meta["model"], key="llm_model")
        key = st.text_input("מפתח API (נשמר בסשן בלבד, לא בקובץ)", type="password", key="llm_key")
        base = st.text_input("Base URL (אופציונלי: Ollama / OpenRouter / פרוקסי)", value=ov.get("base_url", ""), key="llm_base")
        ov.update(provider=prov, model=model, api_key=key or ov.get("api_key", ""), base_url=base)
        st.caption("עדיף להגדיר מפתח כסוד: ב-Streamlit Cloud תחת Secrets, או כמשתנה סביבה ANTHROPIC_API_KEY / OPENAI_API_KEY. "
                   "המפתח נשלח רק לספק שבחרת.")
    return assistant.resolve_config(ov if ov.get("api_key") else {k: v for k, v in ov.items() if k != "api_key"} or None, _secret)


def render() -> None:
    store = core.load_store()
    ui.init_params(store)
    p = ui.current_params()
    st.title("עוזר AI")
    st.caption("שאל על המניה שבדקת, על הכללים או על שיטת הפיבוט")
    cfg = _settings()
    ctx = dict(st.session_state.get("assistant_ctx", {}))
    ctx["portfolio"] = [{"symbol": x["symbol"], "status": x["status"], "since": x.get("since")} for x in store["positions"]]

    seen = [s for s in (f"סווינג: {ctx['swing']['symbol']}" if ctx.get("swing") else None,
                        f"פיבוט: {ctx['pivot']['symbol']}" if ctx.get("pivot") else None,
                        f"{len(ctx['portfolio'])} מניות ברשימה" if ctx["portfolio"] else None) if s]
    head = [(cfg.label, "good")] if cfg else [("ללא AI · מצב בסיסי", "warn")]
    ui.chips(head + ([(s, "good") for s in seen] or [("אין הקשר עדיין — בדוק מניה קודם", "warn")]))

    msgs: list[dict] = st.session_state.setdefault("chat", [])
    for m in msgs:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
    if not msgs:
        st.pills("שאלות מהירות", QUICK, key="chat_pills", on_change=_quick_pick)

    prompt = st.chat_input("שאל משהו…") or st.session_state.pop("chat_pending", None)
    if prompt:
        msgs.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            if cfg:
                reply = st.write_stream(assistant.stream_chat(cfg, assistant.build_system_prompt(p, ctx), msgs))
            else:
                reply = assistant.offline_answer(prompt, ctx)
                st.markdown(reply)
        msgs.append({"role": "assistant", "content": reply})
    if msgs and st.button("נקה שיחה", icon=":material/delete_sweep:"):
        st.session_state["chat"] = []
        st.rerun()
    st.caption("העוזר מסביר ומנתח לפי הכללים והנתונים באפליקציה. אינו יועץ השקעות ויכול לטעות — בדוק לפני שפועלים.")
