"""בדיקות יחידה על נתונים סינתטיים (בלי רשת). הרצה:  python -m unittest discover -s tests -v"""
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd

os.environ.setdefault("SWING_DATA_DIR", tempfile.mkdtemp())
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import assistant  # noqa: E402
import core  # noqa: E402
import datahub  # noqa: E402

P = core.Params(closed_only=False)


def ramp(n=220, slope=0.15, start=100.0, end_date="2026-01-15") -> pd.DataFrame:
    """מגמת עלייה חלקה; נרות ירוקים קטנים. התאריכים בעבר כדי שנר לא ייחשב ״חי״."""
    idx = pd.bdate_range(end=end_date, periods=n)
    close = start + slope * np.arange(n)
    open_ = close - 0.05
    return pd.DataFrame({"Open": open_, "High": close + 0.15, "Low": open_ - 0.15, "Close": close, "Volume": 1e6}, index=idx)


def with_last(df, **kw):
    df = df.copy()
    for k, v in kw.items():
        df.iloc[-1, df.columns.get_loc(k)] = v
    return df


class SwingRules(unittest.TestCase):
    def test_entry_when_all_four_conditions_hold(self):
        ev = core.evaluate(ramp(), P, "T")
        self.assertEqual(ev.code, "ENTRY")
        self.assertTrue(all(c[1] for c in ev.conds))
        self.assertGreater(ev.score, 0)

    def test_red_candle_blocks_entry(self):
        df = ramp()
        c = df["Close"].iloc[-1]
        ev = core.evaluate(with_last(df, Open=c + 0.2), P, "T")
        self.assertFalse(ev.entry)
        self.assertEqual(ev.code, "NEAR")
        self.assertIn("נר ירוק", ev.missing)

    def test_touching_the_average_blocks_entry(self):
        df = ramp()
        ma = df["Close"].rolling(50).mean().iloc[-1]
        ev = core.evaluate(with_last(df, Low=ma - 0.5), P, "T")
        self.assertFalse(ev.entry)

    def test_distance_over_limit_blocks_entry(self):
        ev = core.evaluate(ramp(), core.Params(closed_only=False, max_dist=1.0), "T")
        self.assertFalse(ev.entry)
        self.assertGreater(ev.dist, 1.0)

    def test_exit_requires_red_candle_fully_below_average(self):
        n = 220
        idx = pd.bdate_range(end="2026-01-15", periods=n)
        close = np.r_[np.linspace(100, 130, 170), np.linspace(130, 90, 50)]
        df = pd.DataFrame({"Open": close + 0.5, "High": close + 0.7, "Low": close - 0.2, "Close": close, "Volume": 1e6}, index=idx)
        ev = core.evaluate(df, P, "T")
        self.assertTrue(ev.exit_hint)
        self.assertEqual(ev.code, "EXIT")
        touching = core.evaluate(with_last(df, High=float(df["Close"].rolling(50).mean().iloc[-1]) + 1), P, "T")
        self.assertFalse(touching.exit_hint)

    def test_surge_switches_exit_to_fast_average(self):
        df = ramp()
        base = df["Close"].iloc[-5]
        for k, mult in enumerate((1.06, 1.12, 1.18, 1.26), start=1):  # 4 נרות ירוקים, +26%
            i = len(df) - 5 + k
            px = base * mult
            df.iloc[i, df.columns.get_indexer(["Open", "High", "Low", "Close"])] = [px * 0.97, px * 1.01, px * 0.96, px]
        d = core.prepare(df, P)
        self.assertTrue(bool(d["surge"].iloc[-1]))
        ev = core.evaluate(df, P, "T")
        self.assertTrue(ev.surge_recent)
        self.assertEqual(ev.mode, "MA6")

    def test_run_state_exits_on_ma6_in_surge_mode(self):
        d = core.prepare(ramp(), P)
        n = len(d)
        d["buy"], d["sell"], d["sellf"], d["surge"] = False, False, False, False
        d.iloc[10, d.columns.get_loc("buy")] = True
        d.iloc[20, d.columns.get_loc("surge")] = True
        d.iloc[25, d.columns.get_loc("sellf")] = True   # יציאה מהירה
        d.iloc[40, d.columns.get_loc("sell")] = True    # לא אמורה להיספר
        ev, pos, mode = core.run_state(d)
        kinds = [(i, k) for i, k, _ in ev]
        self.assertEqual(kinds, [(10, "entry"), (20, "surge"), (25, "exit")])
        self.assertFalse(pos)
        self.assertEqual(n, len(d))

    def test_backtest_runs_and_has_no_lookahead_gap(self):
        res = core.backtest(ramp(400), P)
        self.assertIsNotNone(res)
        self.assertEqual(len(res["equity"]), len(res["bh"]))
        self.assertIn("השיטה", res["stats"].columns)
        self.assertGreater(res["equity"].iloc[-1], 1.0)  # מגמת עלייה: ללא הפסד

    def test_live_candle_dropped(self):
        idx = pd.bdate_range(end=pd.Timestamp.now().normalize(), periods=120)
        df = ramp(120).set_axis(idx)
        with mock.patch.object(core, "is_live", return_value=True):
            ev = core.evaluate(df, core.Params(closed_only=True), "T")
        self.assertTrue(ev.live_dropped)
        self.assertEqual(ev.asof, str(idx[-2].date()))


class PivotModel(unittest.TestCase):
    def test_flat_days(self):
        c = np.r_[np.linspace(50, 10, 100), np.full(300, 10.0) + np.sin(np.arange(300)) * 0.5]
        self.assertGreaterEqual(core.flat_days(c, 1.7), 300)

    def test_insider_summary_counts_purchases(self):
        ins = pd.DataFrame({"Insider": ["A", "B", "C"], "Position": ["CEO", "Director", "CFO"],
                            "Start Date": [pd.Timestamp.now() - pd.Timedelta(days=d) for d in (5, 30, 400)],
                            "Shares": [1000, 500, 100], "Value": [5000.0, np.nan, 100.0],
                            "Text": ["Purchase at price 5.00 per share.", "Purchase at price 4.00 per share.", "Sale at price 9 per share."]})
        s = core.insider_summary(ins, 180)
        self.assertEqual((s["buys"], s["buyers"]), (2, 2))
        self.assertAlmostEqual(s["value"], 7000.0)
        self.assertTrue(s["top_role"])

    def test_score_prefers_user_answer_over_auto(self):
        sc = core.score_pivot({"3.1": 0}, {"3.1": 2})
        self.assertEqual(sc["eff"]["3.1"], (0, "user"))
        sc2 = core.score_pivot({}, {"3.1": 2})
        self.assertEqual(sc2["eff"]["3.1"], (2, "auto"))
        self.assertAlmostEqual(sc2["parts"][3]["score"], 100.0)

    def test_verdict_gates(self):
        self.assertEqual(core.verdict(False, 90, 1, 30, 2)[0], "STOP")
        self.assertEqual(core.verdict(None, None, 0, None, 2)[0], "PENDING")
        self.assertEqual(core.verdict(True, 90, 0.3, 30, 2)[0], "INCOMPLETE")
        self.assertEqual(core.verdict(True, 85, 0.9, 30, 2)[0], "OPPORTUNITY")
        self.assertEqual(core.verdict(True, 85, 0.9, 8, 2)[0], "WATCH")      # מזומן קצר
        self.assertEqual(core.verdict(True, 85, 0.9, 30, 4)[0], "WATCH")     # בשלות מאוחרת
        self.assertEqual(core.verdict(True, 85, 0.9, 30, 2, red_flags=1)[0], "TRAP")
        self.assertEqual(core.verdict(True, 30, 0.9, 30, 2)[0], "TRAP")

    def test_pivot_metrics_and_stage2_use_sec_signals(self):
        df = ramp(800, slope=-0.02, start=120)
        ev = [{"date": pd.Timestamp.now().date().isoformat(), "form": "8-K", "items": ["5.02", "1.01"],
               "tags": ["agreement", "mgmt"], "url": "x"}]
        m = core.pivot_metrics(df, {"totalCash": 1e9, "freeCashflow": -1e8, "revenueGrowth": 0.4}, None, core.PivotParams(), ev, None)
        self.assertEqual(m["ev"]["mgmt"], 1)
        s2 = core.stage2_eval(m, core.new_pivot_record(), core.PivotParams())
        by = {i["id"]: i["value"] for i in s2["items"]}
        self.assertTrue(by["mgmt"])           # אות 8-K על שינוי הנהלה
        self.assertTrue(by["cash"])           # 1e9 / (1e8/12) = 120 חודשים
        self.assertTrue(by["seg"])            # 40% ≥ 25%
        self.assertIsNone(by["anchor"])       # ידני בלבד
        self.assertIsNone(s2["passed"])
        self.assertEqual(core.auto_answers(m, core.new_pivot_record(), core.PivotParams())["5.1"], 1)  # אות חלש = חלקי בלבד


class DataHub(unittest.TestCase):
    def test_ttl_cache_serves_stale_when_source_fails(self):
        calls = {"n": 0}

        @datahub.ttl_cache(0, empty=dict)
        def flaky():
            calls["n"] += 1
            if calls["n"] == 1:
                return {"ok": 1}
            raise RuntimeError("boom")

        self.assertEqual(flaky(), {"ok": 1})
        time.sleep(0.01)
        self.assertEqual(flaky(), {"ok": 1})  # גיבוי מהמטמון הישן

    def test_negative_cache_prevents_hammering(self):
        calls = {"n": 0}

        @datahub.ttl_cache(60, empty=list, neg_seconds=60)
        def nothing():
            calls["n"] += 1
            return []

        nothing(), nothing(), nothing()
        self.assertEqual(calls["n"], 1)

    def test_http_retries_then_succeeds_and_breaker_opens_on_403(self):
        h = datahub.Http("TEST-RETRY", per_sec=1000, retries=2)
        r429 = mock.Mock(status_code=429, headers={"Retry-After": "0"})
        r200 = mock.Mock(status_code=200, text="hello", headers={})
        with mock.patch.object(h.session, "get", side_effect=[r429, r200]), mock.patch("time.sleep"):
            self.assertEqual(h.get("http://x"), "hello")
        h2 = datahub.Http("TEST-403", per_sec=1000)
        r403 = mock.Mock(status_code=403, headers={})
        with mock.patch.object(h2.session, "get", return_value=r403):
            self.assertIsNone(h2.get("http://x"))
        self.assertFalse(datahub.HEALTH.allowed("TEST-403"))  # קוצץ המעגל נפתח
        with mock.patch.object(h2.session, "get") as g:
            self.assertIsNone(h2.get("http://x"))
            g.assert_not_called()

    def test_parse_form4_xml(self):
        xml = b"""<ownershipDocument><reportingOwner><reportingOwnerId><rptOwnerName>Jane Doe</rptOwnerName></reportingOwnerId>
        <reportingOwnerRelationship><isOfficer>1</isOfficer><officerTitle>CEO</officerTitle></reportingOwnerRelationship></reportingOwner>
        <nonDerivativeTable><nonDerivativeTransaction><transactionDate><value>2026-09-01</value></transactionDate>
        <transactionCoding><transactionCode>P</transactionCode></transactionCoding>
        <transactionAmounts><transactionShares><value>1000</value></transactionShares><transactionPricePerShare><value>4.25</value></transactionPricePerShare></transactionAmounts>
        </nonDerivativeTransaction><nonDerivativeTransaction><transactionDate><value>2026-09-02</value></transactionDate>
        <transactionCoding><transactionCode>A</transactionCode></transactionCoding>
        <transactionAmounts><transactionShares><value>50</value></transactionShares></transactionAmounts></nonDerivativeTransaction>
        </nonDerivativeTable></ownershipDocument>"""
        with mock.patch.object(datahub._sec, "get", return_value=xml):
            rows = datahub._parse_form4.__wrapped__(1, "0001-26-000001", "xslF345X05/form4.xml")
        self.assertEqual(len(rows), 1)  # רק קוד P/S
        self.assertEqual((rows[0]["Insider"], rows[0]["Position"], rows[0]["Shares"]), ("Jane Doe", "CEO", 1000.0))
        self.assertAlmostEqual(rows[0]["Value"], 4250.0)

    def test_sec_events_classification(self):
        sub = {"filings": {"recent": {"form": ["8-K", "4", "8-K"], "filingDate": ["2026-09-30", "2026-09-20", "2020-01-01"],
                                      "accessionNumber": ["a-1", "a-2", "a-3"], "primaryDocument": ["d1.htm", "d2.xml", "d3.htm"],
                                      "items": ["5.02,9.01", "", "1.01"]}}}
        with mock.patch.object(datahub, "sec_cik", return_value=1), mock.patch.object(datahub, "sec_submissions", return_value=sub):
            ev = datahub.sec_events.__wrapped__("ZZZ", 365)
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0]["tags"], ["mgmt"])

    def test_stooq_fallback_used_when_yahoo_empty(self):
        csv = "Date,Open,High,Low,Close,Volume\n" + "\n".join(f"2026-01-{d:02d},10,11,9,10.5,1000" for d in range(1, 11))
        with mock.patch.object(datahub, "_yf_call", return_value=None), mock.patch.object(datahub._stooq, "get", return_value=csv):
            out = datahub.download_ohlc.__wrapped__(("ABCD",), "1y")
        self.assertIn("ABCD", out)
        self.assertEqual(datahub.SOURCE_OF["ABCD"], "Stooq (גיבוי)")


class AlertsAndAssistant(unittest.TestCase):
    def test_alert_sent_once_per_signal(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(core, "STORE_PATH", Path(tmp) / "s.json"), \
                    mock.patch.object(core, "download_ohlc", return_value={"AAA": ramp()}), \
                    mock.patch.object(core, "send_notification", return_value=["ntfy ✓"]) as send:
                store = core.load_store()
                store["notify"]["ntfy_topic"] = "t"
                core.upsert_position(store, "AAA", "watch")
                first = core.check_positions(store, P)
                second = core.check_positions(core.load_store(), P)
                self.assertEqual(first[0]["kind"], "entry")
                self.assertEqual(send.call_count, 1)  # כפילות נחסמה
                self.assertEqual(second[0]["sent"], [])

    def test_held_position_exit_alert(self):
        idx = pd.bdate_range(end="2026-01-15", periods=220)
        close = np.r_[np.linspace(100, 130, 170), np.linspace(130, 90, 50)]
        df = pd.DataFrame({"Open": close + 0.5, "High": close + 0.7, "Low": close - 0.2, "Close": close, "Volume": 1e6}, index=idx)
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(core, "STORE_PATH", Path(tmp) / "s.json"), \
                    mock.patch.object(core, "download_ohlc", return_value={"BBB": df}), \
                    mock.patch.object(core, "send_notification", return_value=["ntfy ✓"]) as send:
                store = core.load_store()
                store["notify"]["ntfy_topic"] = "t"
                core.upsert_position(store, "BBB", "held", since=str(idx[150].date()))
                rows = core.check_positions(store, P)
                self.assertEqual(rows[0]["kind"], "exit")
                self.assertIn("יציאה", send.call_args[0][1])

    def test_sse_stream_parsing_and_errors(self):
        class FakeResp:
            status_code = 200
            text = ""

            def __init__(self, lines):
                self.lines = lines

            def iter_lines(self, decode_unicode=True):
                return iter(self.lines)

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        anth = ['event: x', 'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"שלום"}}',
                'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":" עולם"}}']
        cfg = assistant.LLMConfig("anthropic", "m", "k")
        with mock.patch("requests.post", return_value=FakeResp(anth)):
            self.assertEqual("".join(assistant.stream_chat(cfg, "sys", [{"role": "user", "content": "hi"}])), "שלום עולם")
        oai = ['data: {"choices":[{"delta":{"content":"A"}}]}', 'data: {"choices":[{"delta":{"content":"B"}}]}', "data: [DONE]"]
        with mock.patch("requests.post", return_value=FakeResp(oai)):
            self.assertEqual("".join(assistant.stream_chat(assistant.LLMConfig("openai", "m", "k"), "s", [{"role": "user", "content": "x"}])), "AB")
        bad = FakeResp([])
        bad.status_code = 401
        with mock.patch("requests.post", return_value=bad):
            out = "".join(assistant.stream_chat(cfg, "s", [{"role": "user", "content": "x"}]))
        self.assertIn("401", out)  # שגיאה ידידותית ולא קריסה

    def test_config_resolution_and_history_trim(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            self.assertIsNone(assistant.resolve_config({}, lambda k: None))
            cfg = assistant.resolve_config({"provider": "openai", "api_key": "sk"}, lambda k: None)
            self.assertEqual((cfg.provider, cfg.api_key), ("openai", "sk"))
        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": "a"}, clear=True):
            self.assertEqual(assistant.resolve_config({}, lambda k: None).provider, "anthropic")
        msgs = [{"role": "assistant", "content": "x" * 20000}, {"role": "user", "content": "q1"}, {"role": "assistant", "content": "a"},
                {"role": "user", "content": "q2"}]
        trimmed = assistant.trim_history(msgs, 100)
        self.assertEqual(trimmed[0]["role"], "user")
        self.assertEqual(trimmed[-1]["content"], "q2")

    def test_context_and_offline_answer(self):
        ev = core.evaluate(ramp(), P, "AAA")
        ctx = {"swing": assistant.ctx_from_eval(ev, P)}
        json.dumps(ctx, ensure_ascii=False)  # חייב להיות ניתן לסריאליזציה
        self.assertIn("AAA", assistant.build_system_prompt(P, ctx))
        self.assertIn("AAA", assistant.offline_answer("?", ctx))


if __name__ == "__main__":
    unittest.main()
