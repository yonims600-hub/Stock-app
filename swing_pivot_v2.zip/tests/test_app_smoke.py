"""בדיקות עשן לממשק (AppTest של Streamlit) עם נתוני שוק מדומים. הרצה:  python -m unittest discover -s tests -v"""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd

os.environ.setdefault("SWING_DATA_DIR", tempfile.mkdtemp())
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from streamlit.testing.v1 import AppTest  # noqa: E402

import core  # noqa: E402


def make_df(n=1300, slope=0.05, start=60.0) -> pd.DataFrame:
    idx = pd.bdate_range(end="2026-01-15", periods=n)
    close = start + slope * np.arange(n) + np.sin(np.arange(n) / 9) * 0.4
    open_ = close - 0.05
    return pd.DataFrame({"Open": open_, "High": close + 0.2, "Low": open_ - 0.2, "Close": close, "Volume": 1e6}, index=idx)


def fake_download(symbols, period="2y"):
    return {s: make_df(250 if period in ("1y", "2y") else 1300, slope=0.15 if period in ("1y", "2y") else -0.01, start=100.0 if period in ("1y", "2y") else 90.0)
            for s in symbols}


FAKE_DEEP = {"rev": pd.Series([100e6, 110e6, 125e6, 140e6], index=pd.date_range("2025-03-31", periods=4, freq="QE")),
             "fcf": pd.Series([-5e6, -3e6, -1e6, 2e6], index=pd.date_range("2025-03-31", periods=4, freq="QE")),
             "gm": pd.Series([40.0, 42.0, 44.0, 47.0], index=pd.date_range("2025-03-31", periods=4, freq="QE")),
             "runway": 40.0, "dilution_pct": 2.0, "rev_yoy_last": 28.0, "gm_last": 47.0, "cash": 3e8}
FAKE_INS = pd.DataFrame({"Insider": ["A"], "Position": ["CEO"], "Start Date": [pd.Timestamp.now() - pd.Timedelta(days=20)],
                         "Shares": [1000], "Value": [9000.0], "Text": ["Purchase at price 9.00 per share."], "Source": ["Yahoo Finance"]})


class Smoke(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        patches = [
            mock.patch.object(core, "STORE_PATH", Path(self.tmp.name) / "store.json"),
            mock.patch.object(core, "download_ohlc", side_effect=fake_download),
            mock.patch.object(core, "get_quote", return_value={"last": 130.0, "prev": 128.0, "pct": 1.56}),
            mock.patch.object(core, "get_info", return_value={"longName": "Test Corp", "sector": "Tech", "industry": "Software",
                                                              "totalCash": 3e8, "freeCashflow": 1e6, "revenueGrowth": 0.28, "grossMargins": 0.47,
                                                              "priceToSalesTrailing12Months": 1.4, "revenuePerShare": 12.0}),
            mock.patch.object(core, "get_insiders", return_value=FAKE_INS),
            mock.patch.object(core, "sec_events", return_value=[{"date": "2026-01-02", "form": "8-K", "items": ["5.02"], "tags": ["mgmt"], "url": "https://sec.gov/x"}]),
            mock.patch.object(core, "fundamentals_deep", return_value=FAKE_DEEP),
            mock.patch.object(core, "get_news", return_value=[{"title": "Headline", "url": "https://x.y", "publisher": "P", "time": pd.Timestamp("2026-01-10"), "source": "t"}]),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        self.addCleanup(self.tmp.cleanup)

    def run_page(self, body: str) -> AppTest:
        at = AppTest.from_string(f"import sys; sys.path.insert(0, r'{ROOT}')\nimport ui\nui.inject_css()\n{body}", default_timeout=60)
        return at.run()

    def assertClean(self, at: AppTest):
        self.assertEqual([e.value for e in at.exception], [])

    def test_swing_check_tab_shows_entry_and_adds_to_list(self):
        at = self.run_page("import swing_view; swing_view.render()")
        self.assertClean(at)
        self.assertIn("נקודת כניסה", " ".join(m.value for m in at.markdown))
        at.button(key="sw_add_watch").click().run()
        self.assertClean(at)
        self.assertEqual([x["symbol"] for x in core.load_store()["positions"]], ["AAPL"])

    def test_scanner_and_alerts_board(self):
        at = self.run_page("import swing_view; swing_view.render()")
        at.button(key="sw_scan_btn").click().run()
        self.assertClean(at)
        res = at.session_state["sw_scan"]["res"]
        self.assertGreater(len(res), 50)
        self.assertTrue(any(e.code == "ENTRY" for e in res))
        store = core.load_store()
        core.upsert_position(store, "AAA", "watch")
        core.upsert_position(store, "BBB", "held", entry_price=100.0)
        core.save_store(store)
        at.run()
        self.assertClean(at)

    def test_rules_tab_persists_parameters(self):
        at = self.run_page("import swing_view; swing_view.render()")
        at.session_state["p_max_dist"] = 2.5
        at.run()
        self.assertClean(at)
        self.assertEqual(core.load_store()["params"]["max_dist"], 2.5)

    def test_pivot_page_renders_with_scores(self):
        at = self.run_page("import pivot_view; pivot_view.render()")
        self.assertClean(at)
        text = " ".join(m.value for m in at.markdown)
        self.assertIn("Test Corp", text)
        at.session_state["qa|AAPL|1.1"] = 2
        at.session_state["s2|AAPL|anchor"] = True
        at.run()
        self.assertClean(at)
        self.assertIn("AAPL", core.load_store()["pivot"])
        self.assertEqual(core.load_store()["pivot"]["AAPL"]["answers"]["1.1"], 2)

    def test_pivot_scan_and_rank(self):
        at = self.run_page("import pivot_view; pivot_view.render()")
        at.session_state["pv_scan_txt"] = "AAA BBB"
        at.button(key="pv_scan_btn").click().run()
        self.assertClean(at)
        self.assertEqual(len(at.session_state["pv_scan"]), 2)
        store = core.load_store()
        store["pivot"]["AAA"] = core.new_pivot_record()
        core.save_store(store)
        at.run()
        self.assertClean(at)

    def test_assistant_offline_answer_with_context(self):
        at = self.run_page("import swing_view, assistant_view\nswing_view.render()\nassistant_view.render()")
        self.assertClean(at)
        at.chat_input[0].set_value("מה מצב המניה?").run()
        self.assertClean(at)
        answers = [m.markdown[0].value for m in at.chat_message if m.name == "assistant"] if at.chat_message else []
        self.assertTrue(any("AAPL" in a for a in answers) or any("AAPL" in str(m.value) for m in at.markdown))

    def test_full_app_entrypoint(self):
        at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
        self.assertClean(at)


if __name__ == "__main__":
    unittest.main()
